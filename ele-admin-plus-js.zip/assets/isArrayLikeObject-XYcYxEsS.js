import{e4 as t,e5 as i,e6 as r,d6 as a,d3 as n}from"./index-C4BxmZrN.js";function b(e,s){return t(i(e,s,r),e+"")}function c(e){return a(e)&&n(e)}export{b,c as i};
