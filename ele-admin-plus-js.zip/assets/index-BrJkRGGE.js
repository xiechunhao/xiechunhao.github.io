import{_ as e,o as c,m as n}from"./index-C4BxmZrN.js";const o={};function r(t,s){return c(),n("div")}const a=e(o,[["render",r]]);export{a as default};
