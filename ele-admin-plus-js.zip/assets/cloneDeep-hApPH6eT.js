import{ez as o}from"./index-C4BxmZrN.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
