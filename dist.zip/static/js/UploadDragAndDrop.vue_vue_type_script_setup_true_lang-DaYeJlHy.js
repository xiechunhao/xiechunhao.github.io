/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as p,R as n,o as d,S as a,Y as l,b as o,Z as _,u as c,cp as r,a6 as u,co as i}from"./vsv-element-plus-CcCXTk6v.js";const g=p({__name:"UploadDragAndDrop",setup(m){return(f,e)=>{const t=_,s=i;return d(),n(s,{action:"/uploadFile",drag:"",multiple:""},{tip:a(()=>e[0]||(e[0]=[o("div",{class:"el-upload__tip"},"jpg/png 文件需小于500kb",-1)])),default:a(()=>[l(t,{class:"el-icon--upload"},{default:a(()=>[l(c(r))]),_:1}),e[1]||(e[1]=o("div",{class:"el-upload__text"},[u(" 将文件拖拽至此处或 "),o("em",null,"点击上传")],-1))]),_:1})}}});export{g as _};
