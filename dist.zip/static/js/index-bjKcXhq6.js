/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d,b as l,L as e,V as t,D as o,o as m}from"./vsv-element-plus-DQNbQgVr.js";import{_ as i}from"./index-DXRDwnmL.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const p={class:"award-container no-background-container"},f=d({name:"Award",__name:"index",setup(u){return(w,x)=>{const _=o("award-wheel"),a=o("vab-card"),n=o("el-col"),c=o("award-grid"),r=o("award-slot-machine"),s=o("el-row");return m(),l("div",p,[e(s,{gutter:20},{default:t(()=>[e(n,{lg:8,md:12,sm:24,xl:8,xs:24},{default:t(()=>[e(a,{title:"大转盘"},{default:t(()=>[e(_)]),_:1})]),_:1}),e(n,{lg:8,md:12,sm:24,xl:8,xs:24},{default:t(()=>[e(a,{title:"九宫格"},{default:t(()=>[e(c)]),_:1})]),_:1}),e(n,{lg:8,md:12,sm:24,xl:8,xs:24},{default:t(()=>[e(a,{title:"老虎机"},{default:t(()=>[e(r)]),_:1})]),_:1})]),_:1})])}}}),k=i(f,[["__scopeId","data-v-9b0c9554"]]);export{k as default};
