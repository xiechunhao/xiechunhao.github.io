/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d,C as o,D as r,o as s}from"./vsv-element-plus-DQNbQgVr.js";const b=d({__name:"TreeDisabledCheckbox",setup(t){const e={children:"children",label:"label",disabled:"disabled"},l=[{id:1,label:"一级 1",children:[{id:3,label:"二级 2-1",children:[{id:4,label:"三级 3-1-1"},{id:5,label:"三级 3-1-2",disabled:!0}]},{id:2,label:"二级 2-2",disabled:!0,children:[{id:6,label:"三级 3-2-1"},{id:7,label:"三级 3-2-2",disabled:!0}]}]}];return(i,n)=>{const a=r("el-tree");return s(),o(a,{data:l,props:e,"show-checkbox":""})}}});export{b as default};
