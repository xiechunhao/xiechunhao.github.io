/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d,b as _,L as n,V as o,D as s,o as l,_ as a}from"./vsv-element-plus-DQNbQgVr.js";const u={class:"statistic-container no-background-container"},b=d({name:"Statistic",__name:"index",setup(m){return(p,t)=>{const c=s("statistic-basic"),e=s("vab-card"),i=s("statistic-countdown"),r=s("statistic-card");return l(),_("div",u,[n(e,null,{header:o(()=>t[0]||(t[0]=[a("基础用法")])),default:o(()=>[n(c)]),_:1}),n(e,null,{header:o(()=>t[1]||(t[1]=[a("倒计时")])),default:o(()=>[n(i)]),_:1}),n(e,null,{header:o(()=>t[2]||(t[2]=[a("卡片")])),default:o(()=>[n(r)]),_:1})])}}});export{b as default};
