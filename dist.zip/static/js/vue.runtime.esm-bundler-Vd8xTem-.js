/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{P as e,at as a}from"./vsv-element-plus-DQNbQgVr.js";const r=e(a);export{r};
