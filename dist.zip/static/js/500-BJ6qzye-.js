/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as c}from"./ErrorContainer.vue_vue_type_style_index_0_lang-BzbS9T53.js";import{d as _,r as o,R as i,o as p,u as n}from"./vsv-element-plus-CcCXTk6v.js";const h=_({__name:"500",setup(f){const e=o("抱歉！"),t=o("服务器发生错误。"),s=o("请稍后重试，或点击下面的按钮返回首页。"),r=o("返回首页");return(m,l)=>{const a=c;return p(),i(a,{btn:n(r),headline:n(t),icon:"500",info:n(s),oops:n(e)},null,8,["btn","headline","info","oops"])}}});export{h as default};
