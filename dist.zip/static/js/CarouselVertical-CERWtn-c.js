/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as i}from"./index-DuUxtc1j.js";import{a as r,o as l,Y as a,S as t,a1 as o,aj as c,bh as p,b as _,X as u,bg as d}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const f={};function m(h,g){const n=p,s=d;return l(),r(o,null,[a(s,{autoplay:!1,direction:"vertical",height:"180px"},{default:t(()=>[(l(),r(o,null,c(3,e=>a(n,{key:e},{default:t(()=>[_("h3",null,u(e),1)]),_:2},1024)),64))]),_:1}),a(s,{autoplay:!1,direction:"vertical",height:"180px",style:{"margin-top":"var(--el-margin)"},type:"card"},{default:t(()=>[(l(),r(o,null,c(3,e=>a(n,{key:e},{default:t(()=>[_("h3",null,u(e),1)]),_:2},1024)),64))]),_:1})],64)}const b=i(f,[["render",m],["__scopeId","data-v-51ffdf24"]]);export{b as default};
