/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as e}from"./index-DXRDwnmL.js";function a(t){return e({url:"/departmentManagement/getList",method:"get",params:t})}const o=t=>e({url:"/departmentManagement/doEdit",method:"post",data:t}),r=t=>e({url:"/departmentManagement/doDelete",method:"post",data:t});export{o as a,r as d,a as g};
