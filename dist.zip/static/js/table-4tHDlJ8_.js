/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as e}from"./index-DXRDwnmL.js";function r(t){return e({url:"/table/getList",method:"get",params:t})}const s=t=>e({url:"/table/doEdit",method:"post",data:t}),d=t=>e({url:"/table/doDelete",method:"post",data:t});export{s as a,d,r as g};
