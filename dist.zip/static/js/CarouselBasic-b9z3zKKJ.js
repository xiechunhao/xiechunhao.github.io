/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as r}from"./index-DuUxtc1j.js";import{R as n,o as a,S as t,a as c,a1 as _,aj as l,Y as p,bh as u,b as m,X as i,bg as d}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const f={};function h(g,x){const o=u,s=d;return a(),n(s,{height:"180px"},{default:t(()=>[(a(),c(_,null,l(3,e=>p(o,{key:e},{default:t(()=>[m("h3",null,i(e),1)]),_:2},1024)),64))]),_:1})}const E=r(f,[["render",h],["__scopeId","data-v-ba208d97"]]);export{E as default};
