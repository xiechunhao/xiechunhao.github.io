/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as t,R as o,o as n,S as l,b as r,U as c,b7 as p}from"./vsv-element-plus-CcCXTk6v.js";const d={class:"right-panel"},i=t({__name:"VabQueryFormRightPanel",props:{span:{type:Number,default:10}},setup(e){return(a,m)=>{const s=p;return n(),o(s,{lg:e.span,md:24,sm:24,xl:e.span,xs:24},{default:l(()=>[r("div",d,[c(a.$slots,"default")])]),_:3},8,["lg","xl"])}}});export{i as _};
