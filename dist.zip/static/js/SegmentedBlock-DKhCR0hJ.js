/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as s,C as a,G as m,u,D as r,o as p}from"./vsv-element-plus-DQNbQgVr.js";const f=s({__name:"SegmentedBlock",setup(c){const e=ref("周一"),n=["周一","周二","周三","周四","周五","周六","周日"];return(d,o)=>{const l=r("el-segmented");return p(),a(l,{modelValue:u(e),"onUpdate:modelValue":o[0]||(o[0]=t=>m(e)?e.value=t:null),block:"",options:n},null,8,["modelValue"])}}});export{f as default};
