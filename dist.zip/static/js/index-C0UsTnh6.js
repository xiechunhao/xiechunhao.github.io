/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as a}from"./index.vue_vue_type_script_setup_true_lang-DPKRueiC.js";import{a as r,s as c}from"./index-DuUxtc1j.js";import{d as m,a as i,o as e,R as o,u as _}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const l={class:"delete-column-container"},x=m({name:"DeleteColumn",__name:"index",setup(p){const n=r(),{theme:s}=c(n);return(u,f)=>{const t=a;return e(),i("div",l,[_(s).layout=="column"?(e(),o(t,{key:0,title:"单栏页面演示"})):(e(),o(t,{key:1,title:"当前布局不支持单栏页面演示",type:"warning"}))])}}});export{x as default};
