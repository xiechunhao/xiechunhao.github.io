/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-04-22 10:29:50 
 */
import{d as r,S as s,o as c,bu as l}from"./vsv-element-plus-DhTKPhs0.js";const f=r({__name:"TreeCustomLeafNodeInLazyMode",setup(m){const n={label:"name",children:"zones",isLeaf:"leaf"},t=(a,e)=>{if(a.level===0)return e([{name:"region"}]);if(a.level>1)return e([]);setTimeout(()=>{e([{name:"leaf",leaf:!0},{name:"zone"}])},500)};return(a,e)=>{const o=l;return c(),s(o,{lazy:"",load:t,props:n,"show-checkbox":""})}}});export{f as _};
