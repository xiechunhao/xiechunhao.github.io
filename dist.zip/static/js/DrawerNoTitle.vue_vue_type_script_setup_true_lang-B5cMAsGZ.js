/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as s,r as u,a as d,o as p,a1 as m,Y as o,a7 as i,S as n,a6 as f,ao as _,u as w,i as V,b as x}from"./vsv-element-plus-CcCXTk6v.js";const k=s({__name:"DrawerNoTitle",setup(B){const a=u(!1);return(N,e)=>{const r=i,l=_;return p(),d(m,null,[o(r,{type:"primary",onClick:e[0]||(e[0]=t=>a.value=!0)},{default:n(()=>e[2]||(e[2]=[f("打开")])),_:1}),o(l,{modelValue:w(a),"onUpdate:modelValue":e[1]||(e[1]=t=>V(a)?a.value=t:null),"append-to-body":"",size:"288px","with-header":!1},{default:n(()=>e[3]||(e[3]=[x("span",null,"我是内容",-1)])),_:1},8,["modelValue"])],64)}}});export{k as _};
