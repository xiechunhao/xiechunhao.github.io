/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as m,b as l,L as e,V as o,D as t,o as i}from"./vsv-element-plus-DQNbQgVr.js";const r={class:"segmented-container no-background-container"},f=m({name:"Segmented",__name:"index",setup(p){return(u,g)=>{const s=t("segmented-basic"),n=t("vab-card"),c=t("segmented-disabled"),_=t("segmented-block"),a=t("segmented-custom-content"),d=t("segmented-custom-style");return i(),l("div",r,[e(n,{title:"基础用法"},{default:o(()=>[e(s)]),_:1}),e(n,{title:"禁用状态"},{default:o(()=>[e(c)]),_:1}),e(n,{title:"Block 分段选择器"},{default:o(()=>[e(_)]),_:1}),e(n,{title:"自定义内容"},{default:o(()=>[e(a)]),_:1}),e(n,{title:"自定义样式"},{default:o(()=>[e(d)]),_:1})])}}});export{f as default};
