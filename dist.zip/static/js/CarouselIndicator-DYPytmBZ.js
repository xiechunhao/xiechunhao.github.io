/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{_ as c}from"./index-DXRDwnmL.js";import{C as n,o,V as t,b as l,a9 as _,L as i,e as d,Z as p,D as a,I as u}from"./vsv-element-plus-DQNbQgVr.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const m={};function f(h,x){const r=a("el-carousel-item"),s=a("el-carousel");return o(),n(s,{height:"180px","indicator-position":"outside"},{default:t(()=>[(o(),l(u,null,_(3,e=>i(r,{key:e},{default:t(()=>[d("h3",null,p(e),1)]),_:2},1024)),64))]),_:1})}const I=c(m,[["render",f],["__scopeId","data-v-97959ccd"]]);export{I as default};
