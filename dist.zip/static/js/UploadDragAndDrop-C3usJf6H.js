/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as m}from"./UploadDragAndDrop.vue_vue_type_script_setup_true_lang-DaYeJlHy.js";import"./vsv-element-plus-CcCXTk6v.js";export{m as default};
