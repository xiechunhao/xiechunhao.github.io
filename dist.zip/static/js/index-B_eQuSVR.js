/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import r from"./StatisticCard-CCju90jZ.js";import m from"./StatisticCountdown-D_bpsDDS.js";import{_ as p}from"./index-DK68u2cP.js";import c from"./StatisticBasic-CETmLgmz.js";import{d as u,a as d,o as l,Y as n,S as o,a6 as _}from"./vsv-element-plus-CcCXTk6v.js";import"./index-DuUxtc1j.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const f={class:"statistic-container no-background-container"},V=u({name:"Statistic",__name:"index",setup(g){return(x,t)=>{const s=c,e=p,a=m,i=r;return l(),d("div",f,[n(e,null,{header:o(()=>t[0]||(t[0]=[_("基础用法")])),default:o(()=>[n(s)]),_:1}),n(e,null,{header:o(()=>t[1]||(t[1]=[_("倒计时")])),default:o(()=>[n(a)]),_:1}),n(e,null,{header:o(()=>t[2]||(t[2]=[_("卡片")])),default:o(()=>[n(i)]),_:1})])}}});export{V as default};
