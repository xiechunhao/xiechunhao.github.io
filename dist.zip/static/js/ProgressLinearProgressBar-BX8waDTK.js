/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as t,b as a,L as s,D as n,o as c}from"./vsv-element-plus-DQNbQgVr.js";import{_ as p}from"./index-DXRDwnmL.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const _={class:"demo-progress"},m=t({__name:"ProgressLinearProgressBar",setup(g){const o=r=>r===100?"Full":`${r}%`;return(r,i)=>{const e=n("el-progress");return c(),a("div",_,[s(e,{percentage:50}),s(e,{format:o,percentage:100}),s(e,{percentage:100,status:"success"}),s(e,{percentage:100,status:"warning"}),s(e,{percentage:50,status:"exception"})])}}}),x=p(m,[["__scopeId","data-v-fb6f12d6"]]);export{x as default};
