/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{ay as e,_ as t}from"./index-DuUxtc1j.js";import{d as r,a as n,o as a,Y as _}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const c={class:"errorLog-container auto-height-container"},s=r({name:"ErrorLog",__name:"index",setup(i){return(m,p)=>{const o=e;return a(),n("div",c,[_(o)])}}}),x=t(s,[["__scopeId","data-v-f8f5fd7d"]]);export{x as default};
