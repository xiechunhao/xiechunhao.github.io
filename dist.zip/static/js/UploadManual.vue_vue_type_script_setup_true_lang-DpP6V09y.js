/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as u,r as d,R as _,o as i,S as o,Y as l,a7 as f,a6 as p,b as c,co as m}from"./vsv-element-plus-CcCXTk6v.js";const g=u({__name:"UploadManual",setup(b){const a=d(),n=()=>{var t;(t=a.value)==null||t.submit()};return(t,e)=>{const s=f,r=m;return i(),_(r,{ref_key:"uploadRef",ref:a,action:"/uploadFile","auto-upload":!1},{trigger:o(()=>[l(s,{type:"primary"},{default:o(()=>e[0]||(e[0]=[p("选择文件")])),_:1})]),tip:o(()=>e[2]||(e[2]=[c("div",{class:"el-upload__tip"},"jpg/png 文件需小于500kb",-1)])),default:o(()=>[l(s,{type:"success",onClick:n},{default:o(()=>e[1]||(e[1]=[p("上传到服务器")])),_:1})]),_:1},512)}}});export{g as _};
