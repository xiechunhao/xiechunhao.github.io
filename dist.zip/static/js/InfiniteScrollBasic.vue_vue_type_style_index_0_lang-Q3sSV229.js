/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as o,r,T as l,cH as c,a as e,o as t,a1 as _,aj as u,X as f,u as m}from"./vsv-element-plus-CcCXTk6v.js";const p={class:"infinite-list",style:{overflow:"auto"}},y=o({__name:"InfiniteScrollBasic",setup(d){const s=r(0),i=()=>{s.value+=2};return(v,h)=>{const a=c;return l((t(),e("ul",p,[(t(!0),e(_,null,u(m(s),n=>(t(),e("li",{key:n,class:"infinite-list-item"},f(n),1))),128))])),[[a,i]])}}});export{y as _};
