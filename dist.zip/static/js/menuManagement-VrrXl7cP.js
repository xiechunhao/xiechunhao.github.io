/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as t}from"./index-DXRDwnmL.js";function o(e){return t({url:"/menuManagement/getTree",method:"get",params:e})}const r=e=>t({url:"/menuManagement/doEdit",method:"post",data:e}),a=e=>t({url:"/menuManagement/doDelete",method:"post",data:e});export{r as a,a as d,o as g};
