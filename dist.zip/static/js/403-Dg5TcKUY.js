/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as c,C as a,u as o,D as f,o as i}from"./vsv-element-plus-DQNbQgVr.js";const u=c({__name:"403",setup(p){const n=ref("抱歉！"),e=ref("您没有操作权限。"),r=ref("当前帐号没有操作权限，请联系管理员。"),t=ref("返回首页");return(_,l)=>{const s=f("error-container");return i(),a(s,{btn:o(t),headline:o(e),icon:"403",info:o(r),oops:o(n)},null,8,["btn","headline","info","oops"])}}});export{u as default};
