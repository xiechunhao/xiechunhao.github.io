/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{k as e}from"./index-DuUxtc1j.js";const n=t=>e({url:"/icon/getList",method:"get",params:t});export{n as g};
