/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as c,C as a,u as o,D as f,o as i}from"./vsv-element-plus-DQNbQgVr.js";const u=c({__name:"404",setup(p){const n=ref("抱歉！"),e=ref("当前页面不存在。"),r=ref("请检查您输入的网址是否正确，或点击下面的按钮返回首页。"),t=ref("返回首页");return(_,l)=>{const s=f("error-container");return i(),a(s,{btn:o(t),headline:o(e),icon:"404",info:o(r),oops:o(n)},null,8,["btn","headline","info","oops"])}}});export{u as default};
