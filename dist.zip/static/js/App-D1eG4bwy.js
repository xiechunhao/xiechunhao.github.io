/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{aH as o}from"./index-DuUxtc1j.js";import"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";export{o as default};
