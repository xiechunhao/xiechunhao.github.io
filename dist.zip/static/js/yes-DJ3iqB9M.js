/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{s}from"./index-BKHDVNUn.js";import{b as n,o,e}from"./vsv-element-plus-DQNbQgVr.js";var t={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16",style:{"enable-background":"new 0 0 16 16"},"xml:space":"preserve"},r=e("path",{style:{fill:"none"},d:"M16 0v16H0V0z"},null,-1),l=e("path",{class:"yes_svg__st1",d:"M12.37 4.38a.601.601 0 0 1 .95.73l-.07.09-5.99 6.43a.61.61 0 0 1-.78.09l-.08-.08-3.63-3.59a.589.589 0 0 1-.01-.84c.21-.21.53-.24.76-.08l.09.07 3.2 3.15 5.56-5.97z"},null,-1),c=[r,l];function i(a,_){return o(),n("svg",t,[].concat(c))}var v={render:i},m=function(){return s({name:"IconYes",component:v})()};export{m as i};
