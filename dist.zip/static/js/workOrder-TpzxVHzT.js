/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as r}from"./index-DXRDwnmL.js";function o(t){return r({url:"/workOrder/getList",method:"get",params:t})}const d=t=>r({url:"/workOrder/doEdit",method:"post",data:t}),s=t=>r({url:"/workOrder/doDelete",method:"post",data:t});export{d as a,s as d,o as g};
