/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as s}from"./index-DuUxtc1j.js";import{R as n,o as a,S as t,a as c,a1 as _,aj as l,Y as p,bh as u,b as i,X as m,bg as d}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const f={};function h(g,x){const o=u,r=d;return a(),n(r,{arrow:"always",height:"180px",interval:5e3},{default:t(()=>[(a(),c(_,null,l(3,e=>p(o,{key:e},{default:t(()=>[i("h3",null,m(e),1)]),_:2},1024)),64))]),_:1})}const y=s(f,[["render",h],["__scopeId","data-v-b782e2f3"]]);export{y as default};
