/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as r,b as c,e as s,L as t,u as n,D as l,V as d,o as m,_ as p}from"./vsv-element-plus-DQNbQgVr.js";import{_ as i}from"./index-DXRDwnmL.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const _={class:"demo-image__placeholder"},f={class:"block"},u={class:"block"},g=r({__name:"ImagePlaceholder",setup(v){const o=ref("https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg");return(b,e)=>{const a=l("el-image");return m(),c("div",_,[s("div",f,[e[0]||(e[0]=s("span",{class:"demonstration"},"Default",-1)),t(a,{src:n(o)},null,8,["src"])]),s("div",u,[e[2]||(e[2]=s("span",{class:"demonstration"},"Custom",-1)),t(a,{src:n(o)},{placeholder:d(()=>e[1]||(e[1]=[s("div",{class:"image-slot"},[p(" Loading "),s("span",{class:"dot"},"...")],-1)])),_:1},8,["src"])])])}}}),V=i(g,[["__scopeId","data-v-21f98424"]]);export{V as default};
