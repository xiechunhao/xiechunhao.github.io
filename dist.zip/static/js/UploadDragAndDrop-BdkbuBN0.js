/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as p,C as d,V as o,D as l,o as _,L as t,e as a,u,al as r,_ as i}from"./vsv-element-plus-DQNbQgVr.js";const x=p({__name:"UploadDragAndDrop",setup(c){return(m,e)=>{const n=l("el-icon"),s=l("el-upload");return _(),d(s,{action:"/uploadFile",drag:"",multiple:""},{tip:o(()=>e[0]||(e[0]=[a("div",{class:"el-upload__tip"},"jpg/png 文件需小于500kb",-1)])),default:o(()=>[t(n,{class:"el-icon--upload"},{default:o(()=>[t(u(r))]),_:1}),e[1]||(e[1]=a("div",{class:"el-upload__text"},[i(" 将文件拖拽至此处或 "),a("em",null,"点击上传")],-1))]),_:1})}}});export{x as default};
