/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as l,b as r,e,L as s,D as a,V as n,o as i,u as d,bj as c}from"./vsv-element-plus-DQNbQgVr.js";import{_ as m}from"./index-DXRDwnmL.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const p={class:"demo-image__error"},u={class:"block"},f={class:"block"},g={class:"image-slot"},v=l({__name:"ImageLoadFailed",setup(b){return(k,o)=>{const t=a("el-image"),_=a("el-icon");return i(),r("div",p,[e("div",u,[o[0]||(o[0]=e("span",{class:"demonstration"},"Default",-1)),s(t)]),e("div",f,[o[1]||(o[1]=e("span",{class:"demonstration"},"Custom",-1)),s(t,null,{error:n(()=>[e("div",g,[s(_,null,{default:n(()=>[s(d(c))]),_:1})])]),_:1})])])}}}),L=m(v,[["__scopeId","data-v-74f8086d"]]);export{L as default};
