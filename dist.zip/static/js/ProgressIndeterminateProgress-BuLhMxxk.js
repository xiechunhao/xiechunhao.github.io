/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as n,b as o,L as t,D as a,o as c}from"./vsv-element-plus-DQNbQgVr.js";import{_ as i}from"./index-DXRDwnmL.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const p={class:"demo-progress"},m=n({__name:"ProgressIndeterminateProgress",setup(d){const s=r=>r===100?"Full":`${r}%`;return(r,_)=>{const e=a("el-progress");return c(),o("div",p,[t(e,{indeterminate:!0,percentage:50}),t(e,{format:s,indeterminate:!0,percentage:100}),t(e,{duration:5,indeterminate:!0,percentage:100,status:"success"}),t(e,{duration:1,indeterminate:!0,percentage:100,status:"warning"}),t(e,{indeterminate:!0,percentage:50,status:"exception"})])}}}),x=i(m,[["__scopeId","data-v-1543ac0c"]]);export{x as default};
