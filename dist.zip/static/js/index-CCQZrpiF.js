/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{a}from"./index-DXRDwnmL.js";import{d as r,b as c,C as o,u as l,D as m,o as e}from"./vsv-element-plus-DQNbQgVr.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const i={class:"delete-column-container"},y=r({name:"DeleteColumn",__name:"index",setup(p){const n=a(),{theme:s}=storeToRefs(n);return(_,u)=>{const t=m("vab-alert");return e(),c("div",i,[l(s).layout=="column"?(e(),o(t,{key:0,title:"单栏页面演示"})):(e(),o(t,{key:1,title:"当前布局不支持单栏页面演示",type:"warning"}))])}}});export{y as default};
