/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as m,b as f,L as l,V as a,D as r,G as _,u as d,I as C,o as c,_ as n,e as V,n as b,ba as k}from"./vsv-element-plus-DQNbQgVr.js";const v=["id"],z=m({__name:"DrawerCustomizationHeader",setup(w){const o=ref(!1);return(x,e)=>{const s=r("el-button"),i=r("el-drawer");return c(),f(C,null,[l(s,{type:"primary",onClick:e[0]||(e[0]=t=>o.value=!0)},{default:a(()=>e[2]||(e[2]=[n("打开")])),_:1}),l(i,{modelValue:d(o),"onUpdate:modelValue":e[1]||(e[1]=t=>_(o)?o.value=t:null),"append-to-body":"","show-close":!1,size:"288px"},{header:a(({close:t,titleId:u,titleClass:p})=>[V("span",{id:u,class:b(p)},"自定义头部",10,v),l(s,{icon:d(k),type:"danger",onClick:t},{default:a(()=>e[3]||(e[3]=[n("关闭")])),_:2},1032,["icon","onClick"])]),default:a(()=>[e[4]||(e[4]=n(" 这是抽屉内容 "))]),_:1},8,["modelValue"])],64)}}});export{z as default};
