/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-04-22 10:29:50 
 */
import{_ as i}from"./index-CYCwqjW3.js";import{b as r,o as l,Z as a,T as t,a2 as o,ai as c,bg as p,e as _,Y as u,bf as f}from"./vsv-element-plus-DhTKPhs0.js";import"./vsv-icon-DsDu4bUA.js";import"./vsv-nprogress-DdytmWMx.js";const d={};function m(g,h){const n=p,s=f;return l(),r(o,null,[a(s,{autoplay:!1,direction:"vertical",height:"180px"},{default:t(()=>[(l(),r(o,null,c(3,e=>a(n,{key:e},{default:t(()=>[_("h3",null,u(e),1)]),_:2},1024)),64))]),_:1}),a(s,{autoplay:!1,direction:"vertical",height:"180px",style:{"margin-top":"var(--el-margin)"},type:"card"},{default:t(()=>[(l(),r(o,null,c(3,e=>a(n,{key:e},{default:t(()=>[_("h3",null,u(e),1)]),_:2},1024)),64))]),_:1})],64)}const b=i(d,[["render",m],["__scopeId","data-v-51ffdf24"]]);export{b as default};
