/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as c,b as o,L as a,e as n,V as s,D as r,I as i,a9 as d,o as l,_ as f,Z as m}from"./vsv-element-plus-DQNbQgVr.js";import{_ as u}from"./index-DXRDwnmL.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const x={class:"scroll-top-container"},y=c({name:"ScrollTop",__name:"index",setup(V){return(b,e)=>{const _=r("el-button"),p=r("el-affix");return l(),o("div",x,[a(p,{offset:152},{default:s(()=>[a(_,{type:"primary"},{default:s(()=>e[0]||(e[0]=[f("下次打开页面时可以自动跳转至您当前滚动条的记录位置")])),_:1})]),_:1}),n("ul",null,[(l(),o(i,null,d(200,t=>n("li",{key:t},"云商城 - "+m(t),1)),64))])])}}}),N=u(y,[["__scopeId","data-v-4d38a9ef"]]);export{N as default};
