/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as t}from"./index-DXRDwnmL.js";function o(e){return t({url:"/userManagement/getList",method:"get",params:e})}const r=e=>t({url:"/userManagement/doEdit",method:"post",data:e}),s=e=>t({url:"/userManagement/doDelete",method:"post",data:e});export{r as a,s as d,o as g};
