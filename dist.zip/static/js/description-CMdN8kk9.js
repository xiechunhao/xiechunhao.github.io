/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{k as t}from"./index-DuUxtc1j.js";const o=()=>t({url:"https://api.vuejs-core.cn/getShopDescription",method:"get"});export{o as g};
