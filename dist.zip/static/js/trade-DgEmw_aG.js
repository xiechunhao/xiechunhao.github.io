/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as e}from"./index-DXRDwnmL.js";const o=t=>e({url:"/trade/getList",method:"get",params:t}),d=t=>e({url:"/trade/doRefund",method:"post",data:t});export{d,o as g};
