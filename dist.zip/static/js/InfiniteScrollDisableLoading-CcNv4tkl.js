/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as m}from"./InfiniteScrollDisableLoading.vue_vue_type_style_index_0_lang-RPG90MDA.js";import"./vsv-element-plus-CcCXTk6v.js";export{m as default};
