/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as r,a,o as n,Y as s,bD as c}from"./vsv-element-plus-CcCXTk6v.js";import{_ as p}from"./index-DuUxtc1j.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const _={class:"demo-progress"},m=r({__name:"ProgressLinearProgressBar",setup(i){const o=t=>t===100?"Full":`${t}%`;return(t,g)=>{const e=c;return n(),a("div",_,[s(e,{percentage:50}),s(e,{format:o,percentage:100}),s(e,{percentage:100,status:"success"}),s(e,{percentage:100,status:"warning"}),s(e,{percentage:50,status:"exception"})])}}}),x=p(m,[["__scopeId","data-v-fb6f12d6"]]);export{x as default};
