/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as s,b as i,L as e,V as n,D as t,o as l}from"./vsv-element-plus-DQNbQgVr.js";const m={class:"drawer-container no-background-container"},b=s({name:"Drawer",__name:"index",setup(u){return(w,p)=>{const o=t("drawer-basic-usage"),a=t("vab-card"),r=t("drawer-no-title"),_=t("drawer-customization-content"),c=t("drawer-customization-header"),d=t("drawer-nested-drawer");return l(),i("div",m,[e(a,{title:"基础用法"},{default:n(()=>[e(o)]),_:1}),e(a,{title:"不添加标题"},{default:n(()=>[e(r)]),_:1}),e(a,{title:"自定义内容"},{default:n(()=>[e(_)]),_:1}),e(a,{title:"自定义头部"},{default:n(()=>[e(c)]),_:1}),e(a,{title:"嵌套抽屉"},{default:n(()=>[e(d)]),_:1})])}}});export{b as default};
