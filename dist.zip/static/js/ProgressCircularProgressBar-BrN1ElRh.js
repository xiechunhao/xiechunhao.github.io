/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as c}from"./index-DuUxtc1j.js";import{a as r,o as s,Y as t,bD as o}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const n={},a={class:"demo-progress"};function p(_,i){const e=o;return s(),r("div",a,[t(e,{percentage:0,type:"circle"}),t(e,{percentage:25,type:"circle"}),t(e,{percentage:100,status:"success",type:"circle"}),t(e,{percentage:70,status:"warning",type:"circle"}),t(e,{percentage:50,status:"exception",type:"circle"})])}const u=c(n,[["render",p],["__scopeId","data-v-95d900d8"]]);export{u as default};
