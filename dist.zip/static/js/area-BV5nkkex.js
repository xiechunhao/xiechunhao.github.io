/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as t}from"./index-DXRDwnmL.js";const r=()=>t({url:"/area/getList",method:"get"});export{r as g};
