/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as u}from"./index.vue_vue_type_script_setup_true_lang-DPKRueiC.js";import{V as c}from"./vue-json-viewer-CoEMWtWz.js";import{c as m,x as p}from"./index-DuUxtc1j.js";import{d as l,f as _,w as d,O as y,a as f,o as h,Y as r,u as a}from"./vsv-element-plus-CcCXTk6v.js";import"./index-79o-Uh7M.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const b={class:"test2-container"},T=l({name:"Query",__name:"query",setup(q){const e=m(),n=p(),{changeTabsMeta:s}=n,t=_({name:"",path:"",query:{}}),o=()=>{t.name=e.name,t.path=e.path,t.query=e.query,s({title:"Query",meta:{title:`Query id=${e.query.id} `}})};return d(t,()=>{o()},{immediate:!0}),y(()=>{o()}),(v,Q)=>{const i=u;return h(),f("div",b,[r(i,{title:"Query id="+a(e).query.id},null,8,["title"]),r(a(c),{copyable:"","expand-depth":5,value:a(t)},null,8,["value"])])}}});export{T as default};
