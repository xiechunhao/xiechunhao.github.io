/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-04-22 10:29:50 
 */
import{_ as m}from"./SegmentedBasic.vue_vue_type_script_setup_true_lang-C5mjbbRl.js";import"./vsv-element-plus-DhTKPhs0.js";export{m as default};
