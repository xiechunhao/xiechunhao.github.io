/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
const a=""+new URL("../jpg/landscape-BDpPTB9a.jpg",import.meta.url).href;export{a as l};
