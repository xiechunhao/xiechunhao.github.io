/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as _,r as o,a as s,o as a,a1 as l,aj as m,b as i,Y as p,X as d,bf as u,u as t}from"./vsv-element-plus-CcCXTk6v.js";import{_ as f}from"./index-DuUxtc1j.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const g={class:"demo-image"},h={class:"demonstration"},k=_({__name:"ImageBasicUsage",setup(v){const n=o(["fill","contain","cover","none","scale-down"]),c=o("https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg");return(B,b)=>{const r=u;return a(),s("div",g,[(a(!0),s(l,null,m(t(n),e=>(a(),s("div",{key:e,class:"block"},[i("span",h,d(e),1),p(r,{fit:e,src:t(c)},null,8,["fit","src"])]))),128))])}}}),E=f(k,[["__scopeId","data-v-941ede7c"]]);export{E as default};
