/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as r,b as p,L as a,V as o,D as n,o as u,_ as l}from"./vsv-element-plus-DQNbQgVr.js";const g={class:"image-container no-background-container"},v=r({name:"Image",__name:"index",setup(c){return(f,e)=>{const d=n("image-basic-usage"),t=n("vab-card"),s=n("image-placeholder"),_=n("image-load-failed"),i=n("image-lazy-load"),m=n("image-preview");return u(),p("div",g,[a(t,null,{header:o(()=>e[0]||(e[0]=[l("基础用法")])),default:o(()=>[a(d)]),_:1}),a(t,null,{header:o(()=>e[1]||(e[1]=[l("占位内容")])),default:o(()=>[a(s)]),_:1}),a(t,null,{header:o(()=>e[2]||(e[2]=[l("加载失败")])),default:o(()=>[a(_)]),_:1}),a(t,null,{header:o(()=>e[3]||(e[3]=[l("懒加载")])),default:o(()=>[a(i)]),_:1}),a(t,null,{header:o(()=>e[4]||(e[4]=[l("图片预览")])),default:o(()=>[a(m)]),_:1})])}}});export{v as default};
