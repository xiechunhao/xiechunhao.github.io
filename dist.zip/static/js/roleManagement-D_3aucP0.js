/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as t}from"./index-DXRDwnmL.js";function n(e){return t({url:"/roleManagement/getList",method:"get",params:e})}const r=e=>t({url:"/roleManagement/doEdit",method:"post",data:e}),a=e=>t({url:"/roleManagement/doDelete",method:"post",data:e});export{r as a,a as d,n as g};
