/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as a,C as n,D as o,o as c}from"./vsv-element-plus-DQNbQgVr.js";const p=a({__name:"TreeDefaultExpandedAndDefaultChecked",setup(t){const e={children:"children",label:"label"},l=[{id:1,label:"一级 1",children:[{id:4,label:"二级 1-1",children:[{id:9,label:"三级 1-1-1"},{id:10,label:"三级 1-1-2"}]}]},{id:2,label:"一级 2",children:[{id:5,label:"二级 2-1"},{id:6,label:"二级 2-2"}]},{id:3,label:"一级 3",children:[{id:7,label:"二级 3-1"},{id:8,label:"二级 3-2"}]}];return(r,i)=>{const d=o("el-tree");return c(),n(d,{data:l,"default-checked-keys":[5],"default-expanded-keys":[2,3],"node-key":"id",props:e,"show-checkbox":""})}}});export{p as default};
