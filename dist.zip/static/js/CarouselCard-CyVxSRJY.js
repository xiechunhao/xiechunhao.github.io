/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{_ as c}from"./index-DXRDwnmL.js";import{C as n,o as a,V as t,b as l,a9 as _,L as p,e as d,Z as i,D as o,I as m}from"./vsv-element-plus-DQNbQgVr.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const u={};function f(h,x){const r=o("el-carousel-item"),s=o("el-carousel");return a(),n(s,{height:"180px",interval:4e3,type:"card"},{default:t(()=>[(a(),l(m,null,_(3,e=>p(r,{key:e},{default:t(()=>[d("h3",null,i(e),1)]),_:2},1024)),64))]),_:1})}const v=c(u,[["render",f],["__scopeId","data-v-f1af3d84"]]);export{v as default};
