/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{k as e}from"./index-DuUxtc1j.js";function r(t){return e({url:"/table/getList",method:"get",params:t})}const s=t=>e({url:"/table/doEdit",method:"post",data:t}),d=t=>e({url:"/table/doDelete",method:"post",data:t});export{s as a,d,r as g};
