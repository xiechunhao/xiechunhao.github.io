/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as u,b as d,L as a,V as n,D as l,G as p,u as m,I as f,o as i,_,e as V}from"./vsv-element-plus-DQNbQgVr.js";const v=u({__name:"DrawerNoTitle",setup(w){const t=ref(!1);return(x,e)=>{const r=l("el-button"),s=l("el-drawer");return i(),d(f,null,[a(r,{type:"primary",onClick:e[0]||(e[0]=o=>t.value=!0)},{default:n(()=>e[2]||(e[2]=[_("打开")])),_:1}),a(s,{modelValue:m(t),"onUpdate:modelValue":e[1]||(e[1]=o=>p(t)?t.value=o:null),"append-to-body":"",size:"288px","with-header":!1},{default:n(()=>e[3]||(e[3]=[V("span",null,"我是内容",-1)])),_:1},8,["modelValue"])],64)}}});export{v as default};
