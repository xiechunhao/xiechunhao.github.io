/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as r}from"./index-DuUxtc1j.js";import{R as n,o as t,S as o,a as c,a1 as _,aj as l,Y as i,bh as p,b as u,X as d,bg as m}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const f={};function h(g,x){const a=p,s=m;return t(),n(s,{height:"180px","indicator-position":"outside"},{default:o(()=>[(t(),c(_,null,l(3,e=>i(a,{key:e},{default:o(()=>[u("h3",null,d(e),1)]),_:2},1024)),64))]),_:1})}const E=r(f,[["render",h],["__scopeId","data-v-97959ccd"]]);export{E as default};
