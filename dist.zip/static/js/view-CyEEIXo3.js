/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{x as c,c as n,_ as m}from"./index-DuUxtc1j.js";import{d as i,r as u,w as _,a as f,o as p,b as l,u as d,k as h}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const v={class:"iframe-container"},x=["src"],b=i({name:"Iframe",__name:"view",setup(k){const s=c(),{changeTabsMeta:o}=s,e=n(),t=u(""),r=()=>{t.value=`https://${e.query.url}`;const a={...e.meta,...e.query};h(()=>{o({title:"Iframe",meta:a})})};return _(e,()=>{r()},{immediate:!0}),(a,w)=>(p(),f("div",v,[l("iframe",{src:d(t)},null,8,x)]))}}),y=m(b,[["__scopeId","data-v-39f74e7c"]]);export{y as default};
