/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as t,r as a,R as m,o as r,i as u,u as c,cA as p}from"./vsv-element-plus-CcCXTk6v.js";const i=t({__name:"SegmentedBlock",setup(_){const e=a("周一"),n=["周一","周二","周三","周四","周五","周六","周日"];return(d,o)=>{const l=p;return r(),m(l,{modelValue:c(e),"onUpdate:modelValue":o[0]||(o[0]=s=>u(e)?e.value=s:null),block:"",options:n},null,8,["modelValue"])}}});export{i as _};
