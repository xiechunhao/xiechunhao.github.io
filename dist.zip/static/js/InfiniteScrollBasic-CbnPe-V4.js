/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as r,Q as a,b as e,I as l,a9 as c,u,o as t,Z as _,X as f}from"./vsv-element-plus-DQNbQgVr.js";const m={class:"infinite-list",style:{overflow:"auto"}},k=r({__name:"InfiniteScrollBasic",setup(p){const s=ref(0),n=()=>{s.value+=2};return(d,v)=>{const o=f("infinite-scroll");return a((t(),e("ul",m,[(t(!0),e(l,null,c(u(s),i=>(t(),e("li",{key:i,class:"infinite-list-item"},_(i),1))),128))])),[[o,n]])}}});export{k as default};
