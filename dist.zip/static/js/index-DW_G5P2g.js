/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as l}from"./index.vue_vue_type_script_setup_true_lang-DPKRueiC.js";import{x as u,c as m,A as p,e as d,B as f,_ as x}from"./index-DuUxtc1j.js";import{d as h,a as b,o as k,Y as e,S as v,u as y,bj as B}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const w={class:"no-layout-container"},g=h({name:"NoLayout",__name:"index",setup(S){const t=u(),a=m(),{delVisitedRoute:o}=t,{exit:s,isFullscreen:n}=p(),c=async()=>{await s(),await o(f(a,!0)),await history.back()};return(A,C)=>{const r=d,_=B,i=l;return k(),b("div",w,[e(_,{content:"全屏",title:y(n)?"退出全屏并返回上一页":"返回上一页",onBack:c},{extra:v(()=>[e(r)]),_:1},8,["title"]),e(i,{title:"刷新浏览器自动退出全屏",type:"success"})])}}}),V=x(g,[["__scopeId","data-v-e7f2f52e"]]);export{V as default};
