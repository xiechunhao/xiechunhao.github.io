/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as e,b as t,L as r,D as n,o as a}from"./vsv-element-plus-DQNbQgVr.js";import{_ as c}from"./index-DXRDwnmL.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const s={class:"errorLog-container auto-height-container"},_=e({name:"ErrorLog",__name:"index",setup(p){return(i,m)=>{const o=n("vab-error-log-content");return a(),t("div",s,[r(o)])}}}),u=c(_,[["__scopeId","data-v-f8f5fd7d"]]);export{u as default};
