/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{_ as p}from"./index-DXRDwnmL.js";import{b as r,o as l,L as t,V as a,I as o,a9 as c,D as _,e as i,Z as u}from"./vsv-element-plus-DQNbQgVr.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const d={};function f(m,h){const n=_("el-carousel-item"),s=_("el-carousel");return l(),r(o,null,[t(s,{autoplay:!1,direction:"vertical",height:"180px"},{default:a(()=>[(l(),r(o,null,c(3,e=>t(n,{key:e},{default:a(()=>[i("h3",null,u(e),1)]),_:2},1024)),64))]),_:1}),t(s,{autoplay:!1,direction:"vertical",height:"180px",style:{"margin-top":"var(--el-margin)"},type:"card"},{default:a(()=>[(l(),r(o,null,c(3,e=>t(n,{key:e},{default:a(()=>[i("h3",null,u(e),1)]),_:2},1024)),64))]),_:1})],64)}const k=p(d,[["render",f],["__scopeId","data-v-51ffdf24"]]);export{k as default};
