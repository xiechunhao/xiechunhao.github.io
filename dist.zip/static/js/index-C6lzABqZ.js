/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as _,a,o,Y as s,b as n,S as r,a7 as p,a6 as i,de as d,a1 as f,aj as m,X as u}from"./vsv-element-plus-CcCXTk6v.js";import{_ as x}from"./index-DuUxtc1j.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const V={class:"scroll-top-container"},y=_({name:"ScrollTop",__name:"index",setup(B){return(S,e)=>{const l=p,c=d;return o(),a("div",V,[s(c,{offset:152},{default:r(()=>[s(l,{type:"primary"},{default:r(()=>e[0]||(e[0]=[i("下次打开页面时可以自动跳转至您当前滚动条的记录位置")])),_:1})]),_:1}),n("ul",null,[(o(),a(f,null,m(200,t=>n("li",{key:t},"Vue Shop Vite - "+u(t),1)),64))])])}}}),g=x(y,[["__scopeId","data-v-ac012dca"]]);export{g as default};
