/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
const e=""+new URL("../png/QR-CvToeGk7.png",import.meta.url).href;export{e as Q};
