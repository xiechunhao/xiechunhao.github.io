/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
const e=""+new URL("../png/QR-CvToeGk7.png",import.meta.url).href;export{e as Q};
