/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as r,e as i}from"./index-DuUxtc1j.js";import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-2NYJ42p3.js";import{Q as p,R as d,o as f,S as e,Y as o,b7 as u,b as n,b8 as b}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const v={},h={class:"data-screen-header"},x={class:"data-go-home"};function k(V,t){const s=p("vab-icon"),a=m,_=i,c=u,l=b;return f(),d(l,null,{default:e(()=>[o(c,{span:24},{default:e(()=>[n("div",h,[o(a,{target:"_blank",to:"/index"},{default:e(()=>[n("div",x,[o(s,{icon:"home-2-line"})])]),_:1}),t[0]||(t[0]=n("span",null,"Vue Shop Vite 工作台",-1)),o(_,{class:"data-fullscreen"})])]),_:1})]),_:1})}const N=r(v,[["render",k],["__scopeId","data-v-0ecb37c3"]]);export{N as default};
