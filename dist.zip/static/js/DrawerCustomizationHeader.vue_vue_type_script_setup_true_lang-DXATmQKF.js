/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as p,r as m,a as f,o as _,a1 as c,Y as t,a7 as C,S as s,a6 as l,ao as V,u as r,i as k,b as w,n as x,cI as b}from"./vsv-element-plus-CcCXTk6v.js";const v=["id"],E=p({__name:"DrawerCustomizationHeader",setup(y){const a=m(!1);return(B,e)=>{const n=C,d=V;return _(),f(c,null,[t(n,{type:"primary",onClick:e[0]||(e[0]=o=>a.value=!0)},{default:s(()=>e[2]||(e[2]=[l("打开")])),_:1}),t(d,{modelValue:r(a),"onUpdate:modelValue":e[1]||(e[1]=o=>k(a)?a.value=o:null),"append-to-body":"","show-close":!1,size:"288px"},{header:s(({close:o,titleId:i,titleClass:u})=>[w("span",{id:i,class:x(u)},"自定义头部",10,v),t(n,{icon:r(b),type:"danger",onClick:o},{default:s(()=>e[3]||(e[3]=[l("关闭")])),_:2},1032,["icon","onClick"])]),default:s(()=>[e[4]||(e[4]=l(" 这是抽屉内容 "))]),_:1},8,["modelValue"])],64)}}});export{E as _};
