/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as r,b as s,I as m,a9 as i,u as o,o as a,e as l,L as _,Z as p,D as d}from"./vsv-element-plus-DQNbQgVr.js";import{_ as f}from"./index-DXRDwnmL.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const u={class:"demo-image"},g={class:"demonstration"},v=r({__name:"ImageBasicUsage",setup(B){const t=ref(["fill","contain","cover","none","scale-down"]),n=ref("https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg");return(h,k)=>{const c=d("el-image");return a(),s("div",u,[(a(!0),s(m,null,i(o(t),e=>(a(),s("div",{key:e,class:"block"},[l("span",g,p(e),1),_(c,{fit:e,src:o(n)},null,8,["fit","src"])]))),128))])}}}),y=f(v,[["__scopeId","data-v-941ede7c"]]);export{y as default};
