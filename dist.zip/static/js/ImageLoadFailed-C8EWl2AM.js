/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as _,a as c,o as l,b as o,Y as e,bf as r,S as a,Z as i,u as d,cG as m}from"./vsv-element-plus-CcCXTk6v.js";import{_ as p}from"./index-DuUxtc1j.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const u={class:"demo-image__error"},f={class:"block"},g={class:"block"},v={class:"image-slot"},b=_({__name:"ImageLoadFailed",setup(k){return(x,s)=>{const t=r,n=i;return l(),c("div",u,[o("div",f,[s[0]||(s[0]=o("span",{class:"demonstration"},"Default",-1)),e(t)]),o("div",g,[s[1]||(s[1]=o("span",{class:"demonstration"},"Custom",-1)),e(t,null,{error:a(()=>[o("div",v,[e(n,null,{default:a(()=>[e(d(m))]),_:1})])]),_:1})])])}}}),h=p(b,[["__scopeId","data-v-74f8086d"]]);export{h as default};
