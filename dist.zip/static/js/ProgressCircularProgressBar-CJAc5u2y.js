/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{_ as t}from"./index-DXRDwnmL.js";import{b as c,o as s,L as r,D as o}from"./vsv-element-plus-DQNbQgVr.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const a={},n={class:"demo-progress"};function p(i,_){const e=o("el-progress");return s(),c("div",n,[r(e,{percentage:0,type:"circle"}),r(e,{percentage:25,type:"circle"}),r(e,{percentage:100,status:"success",type:"circle"}),r(e,{percentage:70,status:"warning",type:"circle"}),r(e,{percentage:50,status:"exception",type:"circle"})])}const u=t(a,[["render",p],["__scopeId","data-v-95d900d8"]]);export{u as default};
