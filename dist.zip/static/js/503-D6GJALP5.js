/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as c,C as a,u as o,D as f,o as i}from"./vsv-element-plus-DQNbQgVr.js";const u=c({__name:"503",setup(p){const n=ref("抱歉！"),e=ref("服务不可用。"),r=ref("服务器当前无法处理请求，可能是由于过载或正在进行维护。"),t=ref("返回首页");return(_,l)=>{const s=f("error-container");return i(),a(s,{btn:o(t),headline:o(e),icon:"503",info:o(r),oops:o(n)},null,8,["btn","headline","info","oops"])}}});export{u as default};
