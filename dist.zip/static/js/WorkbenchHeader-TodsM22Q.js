/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{_ as d}from"./index-DXRDwnmL.js";import{C as i,o as p,V as n,L as o,e as t,D as e}from"./vsv-element-plus-DQNbQgVr.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const m={},f={class:"data-screen-header"},u={class:"data-go-home"};function v(b,a){const c=e("vab-icon"),s=e("vab-link"),_=e("vab-fullscreen"),l=e("el-col"),r=e("el-row");return p(),i(r,null,{default:n(()=>[o(l,{span:24},{default:n(()=>[t("div",f,[o(s,{target:"_blank",to:"/index"},{default:n(()=>[t("div",u,[o(c,{icon:"home-2-line"})])]),_:1}),a[0]||(a[0]=t("span",null,"云商城 工作台",-1)),o(_,{class:"data-fullscreen"})])]),_:1})]),_:1})}const B=d(m,[["render",v],["__scopeId","data-v-b2a034c4"]]);export{B as default};
