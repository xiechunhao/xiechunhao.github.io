/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as i,r,R as p,o as c,S as t,Y as l,b7 as v,cA as f,u as m,i as _,b8 as V}from"./vsv-element-plus-CcCXTk6v.js";const x=i({__name:"SegmentedDisabled",setup(g){const a=r("Mon"),o=r("Mon"),u=[{label:"周一",value:"Mon",disabled:!0},{label:"周二",value:"Tue"},{label:"周三",value:"Wed",disabled:!0},{label:"周四",value:"Thu"},{label:"周五",value:"Fri",disabled:!0},{label:"周六",value:"Sat"},{label:"周日",value:"Sun"}];return(S,e)=>{const s=f,d=v,b=V;return c(),p(b,{gutter:20},{default:t(()=>[l(d,{span:24},{default:t(()=>[l(s,{modelValue:m(a),"onUpdate:modelValue":e[0]||(e[0]=n=>_(a)?a.value=n:null),disabled:"",options:u,style:{"margin-bottom":"var(--el-margin)"}},null,8,["modelValue"])]),_:1}),l(d,{span:24},{default:t(()=>[l(s,{modelValue:m(o),"onUpdate:modelValue":e[1]||(e[1]=n=>_(o)?o.value=n:null),options:u},null,8,["modelValue"])]),_:1})]),_:1})}}});export{x as _};
