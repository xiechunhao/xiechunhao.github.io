/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d,b as i,L as e,V as t,D as o,o as m}from"./vsv-element-plus-DQNbQgVr.js";const p={class:"carousel-container no-background-container"},w=d({name:"Carousel",__name:"index",setup(f){return(b,v)=>{const a=o("carousel-basic"),c=o("vab-card"),n=o("carousel-indicator"),s=o("carousel-arrows"),r=o("carousel-card"),_=o("carousel-vertical"),l=o("el-col"),u=o("el-row");return m(),i("div",p,[e(u,{gutter:20},{default:t(()=>[e(l,{lg:12,md:12,sm:24,xl:12,xs:24},{default:t(()=>[e(c,{title:"基础用法"},{default:t(()=>[e(a)]),_:1}),e(c,{title:"指示器"},{default:t(()=>[e(n)]),_:1}),e(c,{title:"切换箭头"},{default:t(()=>[e(s)]),_:1}),e(c,{title:"卡片模式"},{default:t(()=>[e(r)]),_:1}),e(c,{title:"垂直排列"},{default:t(()=>[e(_)]),_:1})]),_:1})]),_:1})])}}});export{w as default};
