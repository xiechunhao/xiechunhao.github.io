/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-04-22 10:29:50 
 */
import{_ as o}from"./Tabs.vue_vue_type_script_setup_true_lang-C2m1rokq.js";import"./index-D-McxKAu.js";import"./vsv-element-plus-DhTKPhs0.js";import"./index-CYCwqjW3.js";import"./vsv-icon-DsDu4bUA.js";import"./vsv-nprogress-DdytmWMx.js";export{o as default};
