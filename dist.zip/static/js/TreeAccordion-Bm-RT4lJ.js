/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as n,C as r,D as c,o}from"./vsv-element-plus-DQNbQgVr.js";const s=n({__name:"TreeAccordion",setup(t){const e=[{label:"一级 1",children:[{label:"二级 1-1",children:[{label:"三级 1-1-1"}]}]},{label:"一级 2",children:[{label:"二级 2-1",children:[{label:"三级 2-1-1"}]},{label:"二级 2-2",children:[{label:"三级 2-2-1"}]}]},{label:"一级 3",children:[{label:"二级 3-1",children:[{label:"三级 3-1-1"}]},{label:"二级 3-2",children:[{label:"三级 3-2-1"}]}]}],l={children:"children",label:"label"};return(d,b)=>{const a=c("el-tree");return o(),r(a,{accordion:"",data:e,props:l})}}});export{s as default};
