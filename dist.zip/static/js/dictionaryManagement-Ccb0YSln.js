/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as e}from"./index-DXRDwnmL.js";function o(t){return e({url:"/dictionaryManagement/getTree",method:"get",params:t})}function r(t){return e({url:"/dictionaryManagement/getList",method:"get",params:t})}const a=t=>e({url:"/dictionaryManagement/doEdit",method:"post",data:t}),i=t=>e({url:"/dictionaryManagement/doDelete",method:"post",data:t});export{r as a,a as b,i as d,o as g};
