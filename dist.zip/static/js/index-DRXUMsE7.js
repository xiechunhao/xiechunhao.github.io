/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{f as s}from"./index-DuUxtc1j.js";import{d as _,aL as r,a as m,o as t,T as n,R as a,S as c,a6 as i,a7 as f}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const b={class:"throttle-debounce-container"},C=_({name:"ThrottleDebounce",__name:"index",setup(h){const l=()=>{s("节流函数，2秒后允许再次触发","success","hey")},d=()=>{s("防抖函数，每隔1秒允许触发一次","success","hey")};return(v,e)=>{const o=f,p=r("throttle"),u=r("debounce");return t(),m("div",b,[n((t(),a(o,{type:"primary"},{default:c(()=>e[0]||(e[0]=[i("节流函数")])),_:1})),[[p,l]]),n((t(),a(o,{type:"primary"},{default:c(()=>e[1]||(e[1]=[i("防抖函数")])),_:1})),[[u,d]])])}}});export{C as default};
