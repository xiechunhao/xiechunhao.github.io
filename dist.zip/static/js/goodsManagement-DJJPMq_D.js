/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{k as e}from"./index-DuUxtc1j.js";function n(t){return e({url:"/goodsManagement/getList",method:"get",params:t})}const r=t=>e({url:"/table/doDelete",method:"post",data:t});export{r as d,n as g};
