/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as s}from"./index-DuUxtc1j.js";import{a as r,o,Y as t,bD as n}from"./vsv-element-plus-CcCXTk6v.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const a={},c={class:"demo-progress"};function i(d,p){const e=n;return o(),r("div",c,[t(e,{percentage:70,"stroke-width":26,"text-inside":!0}),t(e,{percentage:100,status:"success","stroke-width":24,"text-inside":!0}),t(e,{percentage:80,status:"warning","stroke-width":22,"text-inside":!0}),t(e,{percentage:50,status:"exception","stroke-width":20,"text-inside":!0})])}const f=s(a,[["render",i],["__scopeId","data-v-6df422a8"]]);export{f as default};
