/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as r,b as c,L as e,V as o,D as t,o as _,_ as a}from"./vsv-element-plus-DQNbQgVr.js";const d={class:"infinite-scroll-container no-background-container"},u=r({name:"InfiniteScroll",__name:"index",setup(f){return(m,n)=>{const s=t("infinite-scroll-basic"),i=t("vab-card"),l=t("infinite-scroll-disable-loading");return _(),c("div",d,[e(i,null,{header:o(()=>n[0]||(n[0]=[a("基础用法")])),default:o(()=>[e(s)]),_:1}),e(i,null,{header:o(()=>n[1]||(n[1]=[a("禁用加载")])),default:o(()=>[e(l)]),_:1})])}}});export{u as default};
