/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as c,r,a as d,o as l,b as e,Y as t,bf as m,u as n,S as p,a6 as _}from"./vsv-element-plus-CcCXTk6v.js";import{_ as i}from"./index-DuUxtc1j.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const u={class:"demo-image__placeholder"},f={class:"block"},g={class:"block"},b=c({__name:"ImagePlaceholder",setup(v){const o=r("https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg");return(x,s)=>{const a=m;return l(),d("div",u,[e("div",f,[s[0]||(s[0]=e("span",{class:"demonstration"},"Default",-1)),t(a,{src:n(o)},null,8,["src"])]),e("div",g,[s[2]||(s[2]=e("span",{class:"demonstration"},"Custom",-1)),t(a,{src:n(o)},{placeholder:p(()=>s[1]||(s[1]=[e("div",{class:"image-slot"},[_(" Loading "),e("span",{class:"dot"},"...")],-1)])),_:1},8,["src"])])])}}}),I=i(b,[["__scopeId","data-v-21f98424"]]);export{I as default};
