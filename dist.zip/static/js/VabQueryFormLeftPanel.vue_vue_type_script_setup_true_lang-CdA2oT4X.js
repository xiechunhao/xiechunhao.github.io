/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as t,R as o,o as l,S as n,b as r,U as c,b7 as p}from"./vsv-element-plus-CcCXTk6v.js";const d={class:"left-panel"},f=t({__name:"VabQueryFormLeftPanel",props:{span:{type:Number,default:14}},setup(e){return(a,m)=>{const s=p;return l(),o(s,{lg:e.span,md:24,sm:24,xl:e.span,xs:24},{default:n(()=>[r("div",d,[c(a.$slots,"default")])]),_:3},8,["lg","xl"])}}});export{f as _};
