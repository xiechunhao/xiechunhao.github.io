/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as s,a as o,o as a,Y as t,bD as c}from"./vsv-element-plus-CcCXTk6v.js";import{_ as i}from"./index-DuUxtc1j.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const p={class:"demo-progress"},_=s({__name:"ProgressIndeterminateProgress",setup(m){const n=r=>r===100?"Full":`${r}%`;return(r,u)=>{const e=c;return a(),o("div",p,[t(e,{indeterminate:!0,percentage:50}),t(e,{format:n,indeterminate:!0,percentage:100}),t(e,{duration:5,indeterminate:!0,percentage:100,status:"success"}),t(e,{duration:1,indeterminate:!0,percentage:100,status:"warning"}),t(e,{indeterminate:!0,percentage:50,status:"exception"})])}}}),x=i(_,[["__scopeId","data-v-1543ac0c"]]);export{x as default};
