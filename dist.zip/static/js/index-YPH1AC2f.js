/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as r}from"./InfiniteScrollDisableLoading.vue_vue_type_style_index_0_lang-RPG90MDA.js";import{_ as s}from"./index-DK68u2cP.js";import{_ as c}from"./InfiniteScrollBasic.vue_vue_type_style_index_0_lang-Q3sSV229.js";import{d as l,a as m,o as p,Y as o,S as t,a6 as i}from"./vsv-element-plus-CcCXTk6v.js";import"./index-DuUxtc1j.js";import"./vsv-icon-1Y3OapYK.js";import"./vsv-nprogress-D-M_H-zP.js";const d={class:"infinite-scroll-container no-background-container"},N=l({name:"InfiniteScroll",__name:"index",setup(f){return(u,n)=>{const a=c,e=s,_=r;return p(),m("div",d,[o(e,null,{header:t(()=>n[0]||(n[0]=[i("基础用法")])),default:t(()=>[o(a)]),_:1}),o(e,null,{header:t(()=>n[1]||(n[1]=[i("禁用加载")])),default:t(()=>[o(_)]),_:1})])}}});export{N as default};
