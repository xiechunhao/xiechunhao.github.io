/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{k as t}from"./index-DuUxtc1j.js";const r=()=>t({url:"/area/getList",method:"get"});export{r as g};
