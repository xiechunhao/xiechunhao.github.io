/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{_ as o}from"./orderlist.vue_vue_type_script_setup_true_lang-1FJLaT9E.js";import"./vsv-element-plus-DQNbQgVr.js";import"./trade-DgEmw_aG.js";import"./index-DXRDwnmL.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";import"./clipboard-B9ccURei.js";export{o as default};
