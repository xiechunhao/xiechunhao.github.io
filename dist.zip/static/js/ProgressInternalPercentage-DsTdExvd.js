/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{_ as s}from"./index-DXRDwnmL.js";import{b as r,o,L as t,D as n}from"./vsv-element-plus-DQNbQgVr.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const c={},a={class:"demo-progress"};function i(d,p){const e=n("el-progress");return o(),r("div",a,[t(e,{percentage:70,"stroke-width":26,"text-inside":!0}),t(e,{percentage:100,status:"success","stroke-width":24,"text-inside":!0}),t(e,{percentage:80,status:"warning","stroke-width":22,"text-inside":!0}),t(e,{percentage:50,status:"exception","stroke-width":20,"text-inside":!0})])}const l=s(c,[["render",i],["__scopeId","data-v-6df422a8"]]);export{l as default};
