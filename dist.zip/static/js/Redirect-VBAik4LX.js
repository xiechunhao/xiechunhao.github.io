/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as e,a5 as t,a as o,o as a}from"./vsv-element-plus-CcCXTk6v.js";const n={class:"redirect-container"},_=e({name:"Redirect",__name:"Redirect",setup(r){return t(()=>{setTimeout(()=>{history.back()},500)}),(c,s)=>(a(),o("div",n))}});export{_ as default};
