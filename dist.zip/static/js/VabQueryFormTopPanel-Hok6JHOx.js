/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{_ as s}from"./index-DuUxtc1j.js";import{R as t,o as n,S as _,b as a,U as c,b7 as r}from"./vsv-element-plus-CcCXTk6v.js";const l={},p={class:"top-panel"};function d(o,f){const e=r;return n(),t(e,{span:24},{default:_(()=>[a("div",p,[c(o.$slots,"default")])]),_:3})}const u=s(l,[["render",d]]);export{u as _};
