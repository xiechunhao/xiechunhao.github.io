/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as e,b as t,o}from"./vsv-element-plus-DQNbQgVr.js";const n={class:"redirect-container"},i=e({name:"Redirect",__name:"Redirect",setup(r){return onBeforeMount(()=>{setTimeout(()=>{history.back()},500)}),(c,s)=>(o(),t("div",n))}});export{i as default};
