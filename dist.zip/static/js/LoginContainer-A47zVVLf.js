/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as s,b as c,ag as i,L as o,D as n,ad as l,u as d,o as m}from"./vsv-element-plus-DQNbQgVr.js";import{_ as p}from"./index-DXRDwnmL.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const _=s({name:"LoginContainer",__name:"LoginContainer",setup(u){const e=ref("linear-gradient(to top, var(--el-color-primary), var(--el-color-primary-light-3))");return(a,g)=>{const r=n("vab-icon"),t=n("vab-footer");return m(),c("div",{class:"login-container",style:l({background:d(e),backgroundSize:"100%"})},[i(a.$slots,"default",{},void 0,!0),o(r,{class:"login-background",icon:"background","is-custom-svg":""}),o(t)],4)}}}),C=p(_,[["__scopeId","data-v-31a081d0"]]);export{C as default};
