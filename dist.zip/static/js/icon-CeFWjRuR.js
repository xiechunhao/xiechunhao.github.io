/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as e}from"./index-DXRDwnmL.js";const n=t=>e({url:"/icon/getList",method:"get",params:t});export{n as g};
