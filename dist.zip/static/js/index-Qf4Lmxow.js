/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{d as t,R as a,o as r,S as s,U as _,b8 as n}from"./vsv-element-plus-CcCXTk6v.js";import{_ as c}from"./index-DuUxtc1j.js";const p=t({name:"VabQueryForm",__name:"index",setup(m){return(o,u)=>{const e=n;return r(),a(e,{class:"vab-query-form",gutter:0},{default:s(()=>[_(o.$slots,"default",{},void 0,!0)]),_:3})}}}),f=c(p,[["__scopeId","data-v-a03dcaab"]]);export{f as _};
