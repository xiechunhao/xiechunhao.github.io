/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-04-22 10:29:50 
 */
import{_ as s}from"./index-CYCwqjW3.js";import{S as n,o as a,T as t,b as c,a2 as _,ai as l,Z as p,bg as i,e as u,Y as m,bf as d}from"./vsv-element-plus-DhTKPhs0.js";import"./vsv-icon-DsDu4bUA.js";import"./vsv-nprogress-DdytmWMx.js";const f={};function g(h,x){const o=i,r=d;return a(),n(r,{height:"180px",interval:4e3,type:"card"},{default:t(()=>[(a(),c(_,null,l(3,e=>p(o,{key:e},{default:t(()=>[u("h3",null,m(e),1)]),_:2},1024)),64))]),_:1})}const C=s(f,[["render",g],["__scopeId","data-v-f1af3d84"]]);export{C as default};
