/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 13:58:02 
 */
import{N as e}from"./index-DuUxtc1j.js";import{d as s,c as p,R as i,o as c,az as l,u,bM as m,bN as d,S as f,U as _}from"./vsv-element-plus-CcCXTk6v.js";const x=s({name:"VabLink",__name:"index",props:{to:{type:String,required:!0},target:{type:String,default:""}},setup(o){const t=o,r=p(()=>e(t.to)?"a":"router-link"),a=()=>e(t.to)?{href:t.to,target:"_blank",rel:"noopener"}:{to:t.to,target:t.target};return(n,g)=>(c(),i(l(u(r)),m(d(a())),{default:f(()=>[_(n.$slots,"default")]),_:3},16))}});export{x as _};
