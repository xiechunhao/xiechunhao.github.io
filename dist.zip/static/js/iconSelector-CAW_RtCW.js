/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{d as f,b as d,L as e,V as t,G as m,u as r,D as s,o as b,e as w}from"./vsv-element-plus-DQNbQgVr.js";const x={class:"icon-selector-container"},I=f({name:"IconSelector",__name:"iconSelector",setup(B){const l=ref("24-hours-fill"),o=ref(!1),i=c=>{l.value=c,o.value=!1};return(c,n)=>{const a=s("vab-icon"),p=s("el-button"),_=s("vab-icon-selector"),u=s("el-popover");return b(),d("div",x,[e(u,{visible:r(o),"onUpdate:visible":n[0]||(n[0]=v=>m(o)?o.value=v:null),"popper-class":"icon-selector-popper"},{reference:t(()=>[e(p,null,{default:t(()=>[e(a,{icon:r(l)},null,8,["icon"]),n[1]||(n[1]=w("span",null,"图标选择器",-1)),e(a,{icon:"arrow-down-s-line"})]),_:1})]),default:t(()=>[e(_,{onHandleIcon:i})]),_:1},8,["visible"])])}}});export{I as default};
