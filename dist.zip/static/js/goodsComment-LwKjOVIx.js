/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{c as o}from"./index-DXRDwnmL.js";function s(t){return o({url:"/goodsComment/getList",method:"get",params:t})}const d=t=>o({url:"/goodsComment/doEdit",method:"post",data:t}),n=t=>o({url:"/goodsComment/doDelete",method:"post",data:t});export{d as a,n as d,s as g};
