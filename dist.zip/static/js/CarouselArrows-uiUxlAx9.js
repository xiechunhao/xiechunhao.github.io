/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2025-02-28 11:53:44 
 */
import{_ as c}from"./index-DXRDwnmL.js";import{C as n,o as a,V as o,b as l,a9 as _,L as i,e as m,Z as p,D as r,I as u}from"./vsv-element-plus-DQNbQgVr.js";import"./vsv-icon-BSoeDgwL.js";import"./vsv-nprogress-BCb6Y0ID.js";const d={};function f(h,x){const t=r("el-carousel-item"),s=r("el-carousel");return a(),n(s,{arrow:"always",height:"180px",interval:5e3},{default:o(()=>[(a(),l(u,null,_(3,e=>i(t,{key:e},{default:o(()=>[m("h3",null,p(e),1)]),_:2},1024)),64))]),_:1})}const g=c(d,[["render",f],["__scopeId","data-v-b782e2f3"]]);export{g as default};
