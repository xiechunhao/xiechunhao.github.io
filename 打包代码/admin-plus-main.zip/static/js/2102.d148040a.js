/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[2102],{72102:function(n,t,a){a.r(t),a.d(t,{default:function(){return l}});var s=a(34641);function e(n,t){return(0,s.uX)(),(0,s.CE)("div",null,t[0]||(t[0]=[(0,s.Fv)('<input placeholder="Input Outline" type="text" data-v-35290834><span class="bottom" data-v-35290834></span><span class="right" data-v-35290834></span><span class="top" data-v-35290834></span><span class="left" data-v-35290834></span>',5)]))}function u(n){n.__source="src/views/other/cssfx/components/input-outline.vue"}var p=a(48499);const c={};"function"===typeof u&&u(c);const o=(0,p.A)(c,[["render",e],["__scopeId","data-v-35290834"]]);var l=o}}]);