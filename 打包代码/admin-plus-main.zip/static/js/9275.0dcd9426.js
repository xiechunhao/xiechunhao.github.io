/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[9275],{19275:function(n,u,t){t.r(u),t.d(u,{default:function(){return i}});var e=t(34641);function s(n,u){return(0,e.uX)(),(0,e.CE)("button",null,"Slide")}function c(n){n.__source="src/views/other/cssfx/components/button-slide-up.vue"}var o=t(48499);const r={};"function"===typeof c&&c(r);const f=(0,o.A)(r,[["render",s],["__scopeId","data-v-3585dbf8"]]);var i=f}}]);