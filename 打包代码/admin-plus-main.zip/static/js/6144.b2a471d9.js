/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[6144],{16144:function(n,t,e){e.r(t),e.d(t,{default:function(){return a}});var u=e(34641);function s(n,t){return(0,u.uX)(),(0,u.CE)("button",null,"Slide")}function c(n){n.__source="src/views/other/cssfx/components/button-slide-right.vue"}var o=e(48499);const r={};"function"===typeof c&&c(r);const i=(0,o.A)(r,[["render",s],["__scopeId","data-v-2bb263e9"]]);var a=i}}]);