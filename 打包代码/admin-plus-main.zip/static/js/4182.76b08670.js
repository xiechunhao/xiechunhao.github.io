/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[4182],{44182:function(n,t,e){e.r(t),e.d(t,{default:function(){return i}});var u=e(34641);function r(n,t){return(0,u.uX)(),(0,u.CE)("span",null,"Strikethrough")}function s(n){n.__source="src/views/other/cssfx/components/text-strikethrough.vue"}var c=e(48499);const o={};"function"===typeof s&&s(o);const a=(0,c.A)(o,[["render",r],["__scopeId","data-v-d014204e"]]);var i=a}}]);