/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[8661],{58661:function(a,c,n){n.r(c),n.d(c,{default:function(){return o}});var t=n(34641);function s(a,c){return(0,t.uX)(),(0,t.CE)("div",null,c[0]||(c[0]=[(0,t.Fv)('<input placeholder="Input Trace" type="text" data-v-45c9257c><span class="bottom" data-v-45c9257c></span><span class="right" data-v-45c9257c></span><span class="top" data-v-45c9257c></span><span class="left" data-v-45c9257c></span>',5)]))}function e(a){a.__source="src/views/other/cssfx/components/input-trace.vue"}var p=n(48499);const u={};"function"===typeof e&&e(u);const r=(0,p.A)(u,[["render",s],["__scopeId","data-v-45c9257c"]]);var o=r}}]);