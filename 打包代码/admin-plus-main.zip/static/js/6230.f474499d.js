/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[6230],{23849:function(n,e,t){t.r(e),t.d(e,{default:function(){return i}});var u=t(34641);function s(n,e){return(0,u.uX)(),(0,u.CE)("button",null,"Shine")}function c(n){n.__source="src/views/other/cssfx/components/button-shine.vue"}var o=t(48499);const r={};"function"===typeof c&&c(r);const f=(0,o.A)(r,[["render",s],["__scopeId","data-v-2efec750"]]);var i=f}}]);