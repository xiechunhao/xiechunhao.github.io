/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[5173],{55173:function(n,e,u){u.r(e),u.d(e,{default:function(){return o}});var t=u(34641);function c(n,e){return(0,t.uX)(),(0,t.CE)("div",null,e[0]||(e[0]=[(0,t.Lk)("input",{placeholder:"Input Underline",type:"text"},null,-1),(0,t.Lk)("span",null,null,-1)]))}function l(n){n.__source="src/views/other/cssfx/components/input-underline2.vue"}var r=u(48499);const s={};"function"===typeof l&&l(s);const i=(0,r.A)(s,[["render",c],["__scopeId","data-v-3b1311ca"]]);var o=i}}]);