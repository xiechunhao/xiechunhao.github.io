/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[2542],{82542:function(n,t,u){u.r(t),u.d(t,{default:function(){return a}});var e=u(34641);function s(n,t){return(0,e.uX)(),(0,e.CE)("span",null,"Highlight")}function c(n){n.__source="src/views/other/cssfx/components/text-highlight-up.vue"}var r=u(48499);const i={};"function"===typeof c&&c(i);const o=(0,r.A)(i,[["render",s],["__scopeId","data-v-50339288"]]);var a=o}}]);