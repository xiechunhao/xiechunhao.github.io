/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[8114],{48114:function(n,u,t){t.r(u),t.d(u,{default:function(){return a}});var e=t(34641);function s(n,u){return(0,e.uX)(),(0,e.CE)("button",null,"Pulse")}function c(n){n.__source="src/views/other/cssfx/components/button-pulse.vue"}var o=t(48499);const r={};"function"===typeof c&&c(r);const f=(0,o.A)(r,[["render",s],["__scopeId","data-v-2c5c1fd3"]]);var a=f}}]);