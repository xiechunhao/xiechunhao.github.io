/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[9344],{49344:function(n,e,t){t.r(e),t.d(e,{default:function(){return a}});var u=t(34641);function c(n,e){return(0,u.uX)(),(0,u.CE)("button",null,"Jelly")}function s(n){n.__source="src/views/other/cssfx/components/button-jelly.vue"}var o=t(48499);const r={};"function"===typeof s&&s(r);const l=(0,o.A)(r,[["render",c],["__scopeId","data-v-1dcb8e10"]]);var a=l}}]);