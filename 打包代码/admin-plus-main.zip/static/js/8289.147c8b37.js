/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[8289],{18289:function(n,e,u){u.r(e),u.d(e,{default:function(){return i}});var t=u(34641);function l(n,e){return(0,t.uX)(),(0,t.CE)("div",null,e[0]||(e[0]=[(0,t.Lk)("input",{placeholder:"Input Underline",type:"text"},null,-1),(0,t.Lk)("span",null,null,-1)]))}function r(n){n.__source="src/views/other/cssfx/components/input-underline.vue"}var s=u(48499);const c={};"function"===typeof r&&r(c);const a=(0,s.A)(c,[["render",l],["__scopeId","data-v-a61d880a"]]);var i=a}}]);