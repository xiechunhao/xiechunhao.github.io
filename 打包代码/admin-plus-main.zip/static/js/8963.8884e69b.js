/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[8963],{58963:function(n,t,e){e.r(t),e.d(t,{default:function(){return a}});var u=e(34641);function s(n,t){return(0,u.uX)(),(0,u.CE)("span",null,"Highlight")}function c(n){n.__source="src/views/other/cssfx/components/text-highlight-right.vue"}var r=e(48499);const i={};"function"===typeof c&&c(i);const o=(0,r.A)(i,[["render",s],["__scopeId","data-v-399e9ed2"]]);var a=o}}]);