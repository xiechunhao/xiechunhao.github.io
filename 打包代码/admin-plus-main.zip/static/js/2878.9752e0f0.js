/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[2878],{42878:function(n,t,u){u.r(t),u.d(t,{default:function(){return f}});var e=u(34641);function c(n,t){return(0,e.uX)(),(0,e.CE)("button",null,"Slide")}function s(n){n.__source="src/views/other/cssfx/components/button-slide-down.vue"}var o=u(48499);const r={};"function"===typeof s&&s(r);const a=(0,o.A)(r,[["render",c],["__scopeId","data-v-05c3fac0"]]);var f=a}}]);