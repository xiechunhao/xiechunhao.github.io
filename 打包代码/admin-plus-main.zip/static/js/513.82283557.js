/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[513],{40513:function(n,s,e){e.r(s),e.d(s,{default:function(){return f}});var t=e(34641);function u(n,s){return(0,t.uX)(),(0,t.CE)("span",null,"Bars")}function c(n){n.__source="src/views/other/cssfx/components/text-bars.vue"}var r=e(48499);const a={};"function"===typeof c&&c(a);const o=(0,r.A)(a,[["render",u],["__scopeId","data-v-282d4c75"]]);var f=o}}]);