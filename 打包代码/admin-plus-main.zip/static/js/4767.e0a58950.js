/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[4767],{94767:function(n,e,t){t.r(e),t.d(e,{default:function(){return i}});var u=t(34641);function s(n,e){return(0,u.uX)(),(0,u.CE)("span",null,"Overline")}function r(n){n.__source="src/views/other/cssfx/components/text-overline2.vue"}var c=t(48499);const o={};"function"===typeof r&&r(o);const a=(0,c.A)(o,[["render",s],["__scopeId","data-v-e0990630"]]);var i=a}}]);