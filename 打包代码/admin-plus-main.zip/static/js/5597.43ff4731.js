/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[5597],{95597:function(e,a,t){t.r(a),t.d(a,{default:function(){return c}});var n=t(34641);function r(e,a,t,r,s,o){const u=(0,n.g2)("vab-json-viewer");return(0,n.uX)(),(0,n.CE)("div",null,[(0,n.bF)(u,{copyable:"","expand-depth":5,sort:"",value:e.data},null,8,["value"])])}var s=t(98969),o=t.n(s),u=(0,n.pM)({components:{VabJsonViewer:o()},props:{graphData:{type:Object,default:()=>{}}},data(){return{data:[]}},created(){this.data=JSON.parse(JSON.stringify([{edges:this.graphData.edges,nodes:this.graphData.nodes}]))}});function p(e){e.__source="src/views/other/workflow/components/lFComponents/DataDialog.vue"}var d=t(48499);"function"===typeof p&&p(u);const i=(0,d.A)(u,[["render",r]]);var c=i}}]);