/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[2477],{12477:function(n,s,e){e.r(s),e.d(s,{default:function(){return f}});var t=e(34641);function u(n,s){return(0,t.uX)(),(0,t.CE)("span",null,"Bars")}function r(n){n.__source="src/views/other/cssfx/components/text-barsr3.vue"}var c=e(48499);const a={};"function"===typeof r&&r(a);const o=(0,c.A)(a,[["render",u],["__scopeId","data-v-fb5d1d88"]]);var f=o}}]);