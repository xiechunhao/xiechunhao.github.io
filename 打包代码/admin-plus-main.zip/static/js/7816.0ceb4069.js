/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2024-12-11 15:03:04
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[7816],{79715:function(t,e,n){n.r(e),n.d(e,{default:function(){return h}});var a=n(46569),s=(n(72688),n(775),n(15275)),c=(n(50726),n(43027),n(34641)),u=n(40664),o=n(99328),i=n(12176);const r={class:"no-layout-container"},l=(0,c.pM)({name:"NoLayout"});var p=(0,c.pM)({...l,setup(t){const e=(0,o.Z)(),n=(0,i.lq)(),{delVisitedRoute:l}=e,p=(0,i.rd)(),d=async()=>{await p.push({path:"/index"}),await l((0,u.QG)(n,!0))};return(t,e)=>{const n=s.IO,u=a.KR;return(0,c.uX)(),(0,c.CE)("div",r,[(0,c.bF)(n,{content:"无框",title:"返回首页",onBack:d}),(0,c.bF)(u,{closable:!1,title:"无框示例",type:"success"})])}}});function d(t){t.__source="src/views/other/noLayout/index.vue"}var f=n(48499);"function"===typeof d&&d(p);const v=(0,f.A)(p,[["__scopeId","data-v-cce00820"]]);var h=v}}]);