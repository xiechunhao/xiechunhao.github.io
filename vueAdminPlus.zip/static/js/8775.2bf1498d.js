/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[8775],{58775:function(n,t,a){a.r(t),a.d(t,{default:function(){return l}});var c=a(34641);function s(n,t){return(0,c.uX)(),(0,c.CE)("div",null,t[0]||(t[0]=[(0,c.Fv)('<input placeholder="Input Outline" type="text" data-v-66c3671c><span class="bottom" data-v-66c3671c></span><span class="right" data-v-66c3671c></span><span class="top" data-v-66c3671c></span><span class="left" data-v-66c3671c></span>',5)]))}function e(n){n.__source="src/views/other/cssfx/components/input-outline2.vue"}var u=a(48499);const p={};"function"===typeof e&&e(p);const o=(0,u.A)(p,[["render",s],["__scopeId","data-v-66c3671c"]]);var l=o}}]);