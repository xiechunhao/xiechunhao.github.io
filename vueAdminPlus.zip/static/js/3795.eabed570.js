/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[3795],{33795:function(n,u,t){t.r(u),t.d(u,{default:function(){return b}});var e=t(34641);function s(n,u){return(0,e.uX)(),(0,e.CE)("button",null,"Bubble")}function c(n){n.__source="src/views/other/cssfx/components/button-bubble-bl.vue"}var o=t(48499);const r={};"function"===typeof c&&c(r);const a=(0,o.A)(r,[["render",s],["__scopeId","data-v-9a414a94"]]);var b=a}}]);