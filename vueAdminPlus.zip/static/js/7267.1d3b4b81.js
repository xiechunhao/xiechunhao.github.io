/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[7267],{77267:function(n,e,s){s.r(e),s.d(e,{default:function(){return i}});var t=s(34641);function u(n,e){return(0,t.uX)(),(0,t.CE)("span",null,"Pillars")}function r(n){n.__source="src/views/other/cssfx/components/text-pillars3.vue"}var c=s(48499);const a={};"function"===typeof r&&r(a);const o=(0,c.A)(a,[["render",u],["__scopeId","data-v-0d7a0e21"]]);var i=o}}]);