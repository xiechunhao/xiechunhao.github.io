/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[4395],{94395:function(n,u,e){e.r(u),e.d(u,{default:function(){return a}});var t=e(34641);function s(n,u){return(0,t.uX)(),(0,t.CE)("button",null,"Bubble")}function c(n){n.__source="src/views/other/cssfx/components/button-bubble-br.vue"}var o=e(48499);const r={};"function"===typeof c&&c(r);const f=(0,o.A)(r,[["render",s],["__scopeId","data-v-83e7f72e"]]);var a=f}}]);