/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[8153],{32014:function(e,n,u){u.r(n),u.d(n,{default:function(){return f}});var t=u(56637),s=(u(21332),u(3891),u(11551)),a=(u(64731),u(34641));const l={class:"menu1-1-1-1-container"};function c(e,n,u,c,o,r){const d=s.WK,i=t.KR;return(0,a.uX)(),(0,a.CE)("div",l,[(0,a.bF)(i,{closable:!1,title:"多级路由 1-1-1-1",type:"success"},{default:(0,a.k6)((()=>[(0,a.bF)(d,{modelValue:e.value,"onUpdate:modelValue":n[0]||(n[0]=n=>e.value=n)},null,8,["modelValue"])])),_:1})])}var o=u(37489),r=(0,a.pM)({name:"Menu1111",setup(){const e=(0,o.KR)("");return{value:e}}});function d(e){e.__source="src/views/other/nested/menu1/menu1-1/menu1-1-1/menu1-1-1-1/index.vue"}var i=u(48499);"function"===typeof d&&d(r);const m=(0,i.A)(r,[["render",c]]);var f=m}}]);