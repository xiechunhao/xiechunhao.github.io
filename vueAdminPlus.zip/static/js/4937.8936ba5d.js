/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[4937],{64937:function(n,e,u){u.r(e),u.d(e,{default:function(){return f}});var t=u(34641);function s(n,e){return(0,t.uX)(),(0,t.CE)("span",null,"Underline")}function r(n){n.__source="src/views/other/cssfx/components/text-underline3.vue"}var c=u(48499);const a={};"function"===typeof r&&r(a);const o=(0,c.A)(a,[["render",s],["__scopeId","data-v-2a3e4ffa"]]);var f=o}}]);