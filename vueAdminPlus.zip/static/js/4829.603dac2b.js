/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[4829],{84829:function(n,u,t){t.r(u),t.d(u,{default:function(){return f}});var e=t(34641);function c(n,u){return(0,e.uX)(),(0,e.CE)("button",null,"Bubble")}function s(n){n.__source="src/views/other/cssfx/components/button-bubble-tl.vue"}var o=t(48499);const r={};"function"===typeof s&&s(r);const a=(0,o.A)(r,[["render",c],["__scopeId","data-v-9a9724c0"]]);var f=a}}]);