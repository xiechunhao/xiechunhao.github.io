/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[6005,9078],{54654:function(e,n,a){a.r(n),a.d(n,{default:function(){return f}});var u=a(36498),o=(a(21332),a(57593),a(34641));const l={class:"upload-container"};function t(e,n,a,t,r,d){const p=(0,o.g2)("vab-upload"),s=u.S2;return(0,o.uX)(),(0,o.CE)("div",l,[(0,o.bF)(p,{ref:"vabUploadRef",limit:50,name:"file",size:2,url:"/upload"},null,512),(0,o.bF)(s,{type:"primary",onClick:n[0]||(n[0]=n=>e.handleShow())},{default:(0,o.k6)((()=>n[1]||(n[1]=[(0,o.eW)("模拟上传")]))),_:1})])}var r=a(32379),d=a(37489),p=(0,o.pM)({name:"Upload",components:{VabUpload:r["default"]},setup(){const e=(0,d.KR)(),n=()=>{e.value.handleShow()};return{vabUploadRef:e,handleShow:n}}});function s(e){e.__source="src/views/other/upload/index.vue"}var c=a(48499);"function"===typeof s&&s(p);const i=(0,c.A)(p,[["render",t]]);var f=i}}]);