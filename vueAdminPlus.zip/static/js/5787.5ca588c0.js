/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[5787],{27492:function(e,n,l){l.r(n),l.d(n,{default:function(){return d}});var t=l(56637),u=(l(21332),l(3891),l(34641));const o={class:"delete-column-container"};function c(e,n,l,c,s,a){const r=t.KR;return(0,u.uX)(),(0,u.CE)("div",o,[(0,u.bF)(r,{closable:s.closable,title:s.title},null,8,["closable","title"])])}var s={name:"DeleteColumn",data(){return{closable:!1,title:"当前页面示例仅在分栏布局中只有一个children时在路由中配置noColumn时生效，用于隐藏二级菜单"}}};function a(e){e.__source="src/views/noColumn/deleteColumn/index.vue"}var r=l(48499);"function"===typeof a&&a(s);const i=(0,r.A)(s,[["render",c]]);var d=i}}]);