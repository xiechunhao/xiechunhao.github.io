/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[4063],{84063:function(n,s,e){e.r(s),e.d(s,{default:function(){return i}});var t=e(34641);function u(n,s){return(0,t.uX)(),(0,t.CE)("span",null,"Pillars")}function c(n){n.__source="src/views/other/cssfx/components/text-pillars.vue"}var r=e(48499);const a={};"function"===typeof c&&c(a);const o=(0,r.A)(a,[["render",u],["__scopeId","data-v-c2d97b58"]]);var i=o}}]);