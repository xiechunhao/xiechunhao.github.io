/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[4686],{74686:function(e,r,t){t.r(r),t.d(r,{default:function(){return l}});var a=t(34641);const n={class:"iframe-container"},s=["src"];function u(e,r,t,u,i,c){return(0,a.uX)(),(0,a.CE)("div",n,[(0,a.Lk)("iframe",{frameborder:"0",src:e.url},null,8,s)])}var i=t(66183),c=t(56848),h=(0,a.pM)({name:"Iframe",data(){return{url:""}},watch:{$route:"handleIframe"},created(){this.handleIframe()},methods:{...(0,c.i0)(i.Z,["changeTabsMeta"]),handleIframe(){this.url=`https://${this.$route.query.url}`;const e={...this.$route.meta,...this.$route.query};this.$nextTick((()=>{this.changeTabsMeta({title:"Iframe",meta:e})}))}}});function o(e){e.__source="src/views/other/iframe/view.vue"}var f=t(48499);"function"===typeof o&&o(h);const d=(0,f.A)(h,[["render",u],["__scopeId","data-v-053d42bc"]]);var l=d}}]);