/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[9414],{39414:function(n,r,u){u.r(r),u.d(r,{default:function(){return f}});var e=u(34641),o=u(27386);function i(n,r,u,i,t,c){return(0,e.uX)(),(0,e.CE)("div",null,(0,o.v_)(n.chuzhixinjiayou.chuzhixinjiayou),1)}var t=(0,e.pM)({name:"ErrorTest"});function c(n){n.__source="src/views/other/errorLog/components/ErrorTest.vue"}var s=u(48499);"function"===typeof c&&c(t);const a=(0,s.A)(t,[["render",i]]);var f=a}}]);