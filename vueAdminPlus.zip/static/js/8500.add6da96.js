/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2025-02-19 17:40:53
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[8500],{98500:function(n,e,t){t.r(e),t.d(e,{default:function(){return o}});var u=t(34641);const i={class:"github-external-link-container"};function r(n,e,t,r,s,a){return(0,u.uX)(),(0,u.CE)("div",i)}var s={name:"GithubExternalLink",setup(){(0,u.sV)((()=>{}))}};function a(n){n.__source="src/views/github/githubExternalLink/index.vue"}var c=t(48499);"function"===typeof a&&a(s);const l=(0,c.A)(s,[["render",r]]);var o=l}}]);