/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as n,o as p,S as d,T as a,e as o,W as l,u as _,c2 as c,a8 as r,_ as u,c1 as i}from"./vsv-element-plus-DDEqdpLt.js";const g=n({__name:"UploadDragAndDrop",setup(m){return(f,e)=>{const t=u,s=i;return p(),d(s,{action:"/uploadFile",drag:"",multiple:""},{tip:a(()=>e[0]||(e[0]=[o("div",{class:"el-upload__tip"},"jpg/png 文件需小于500kb",-1)])),default:a(()=>[l(t,{class:"el-icon--upload"},{default:a(()=>[l(_(c))]),_:1}),e[1]||(e[1]=o("div",{class:"el-upload__text"},[r(" 将文件拖拽至此处或 "),o("em",null,"点击上传")],-1))]),_:1})}}});export{g as _};
