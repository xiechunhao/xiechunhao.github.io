/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as p,r as i,o as n,S as d,T as a,e as r,W as u,a8 as f,u as m,h as c,a9 as _,c1 as g}from"./vsv-element-plus-DDEqdpLt.js";const y=p({__name:"UploadFileListWithThumbnail",setup(b){const t=i([{name:"food.jpeg",url:"https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100"},{name:"food2.jpeg",url:"https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100"}]);return(j,e)=>{const o=_,l=g;return n(),d(l,{"file-list":m(t),"onUpdate:fileList":e[0]||(e[0]=s=>c(t)?t.value=s:null),action:"/uploadFile","list-type":"picture"},{tip:a(()=>e[2]||(e[2]=[r("div",{class:"el-upload__tip"},"jpg/png 文件需小于500kb",-1)])),default:a(()=>[u(o,{type:"primary"},{default:a(()=>e[1]||(e[1]=[f("点击上传")])),_:1})]),_:1},8,["file-list"])}}});export{y as _};
