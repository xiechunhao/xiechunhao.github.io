/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d,o as r,S as i,bv as o}from"./vsv-element-plus-DDEqdpLt.js";const b=d({__name:"TreeDisabledCheckbox",setup(s){const e={children:"children",label:"label",disabled:"disabled"},l=[{id:1,label:"一级 1",children:[{id:3,label:"二级 2-1",children:[{id:4,label:"三级 3-1-1"},{id:5,label:"三级 3-1-2",disabled:!0}]},{id:2,label:"二级 2-2",disabled:!0,children:[{id:6,label:"三级 3-2-1"},{id:7,label:"三级 3-2-2",disabled:!0}]}]}];return(c,n)=>{const a=o;return r(),i(a,{data:l,props:e,"show-checkbox":""})}}});export{b as _};
