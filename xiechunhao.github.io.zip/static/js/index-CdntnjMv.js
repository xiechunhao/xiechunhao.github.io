/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as _,o as a,b as o,W as s,T as n,a8 as p,e as r,a3 as i,aj as d,a9 as f,cT as m,a1 as u}from"./vsv-element-plus-DDEqdpLt.js";import{_ as x}from"./index-CJ7U9r9H.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const V={class:"scroll-top-container"},y=_({name:"ScrollTop",__name:"index",setup(B){return(T,e)=>{const c=f,l=m;return a(),o("div",V,[s(l,{offset:152},{default:n(()=>[s(c,{type:"primary"},{default:n(()=>e[0]||(e[0]=[p("下次打开页面时可以自动跳转至您当前滚动条的记录位置")])),_:1})]),_:1}),r("ul",null,[(a(),o(i,null,d(200,t=>r("li",{key:t},"Vue Shop Vite - "+u(t),1)),64))])])}}}),b=x(y,[["__scopeId","data-v-ac012dca"]]);export{b as default};
