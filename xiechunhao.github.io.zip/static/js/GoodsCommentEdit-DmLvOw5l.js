/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as o}from"./GoodsCommentEdit.vue_vue_type_script_setup_true_lang-yqkyygeb.js";import"./index-CJ7U9r9H.js";import"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";export{o as default};
