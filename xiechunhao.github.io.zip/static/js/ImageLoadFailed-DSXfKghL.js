/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as _,o as c,b as l,e as o,W as e,T as a,u as r,cj as d,bd as i,_ as m}from"./vsv-element-plus-DDEqdpLt.js";import{_ as p}from"./index-CJ7U9r9H.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const u={class:"demo-image__error"},f={class:"block"},g={class:"block"},v={class:"image-slot"},b=_({__name:"ImageLoadFailed",setup(k){return(x,s)=>{const t=i,n=m;return c(),l("div",u,[o("div",f,[s[0]||(s[0]=o("span",{class:"demonstration"},"Default",-1)),e(t)]),o("div",g,[s[1]||(s[1]=o("span",{class:"demonstration"},"Custom",-1)),e(t,null,{error:a(()=>[o("div",v,[e(n,null,{default:a(()=>[e(r(d))]),_:1})])]),_:1})])])}}}),h=p(b,[["__scopeId","data-v-74f8086d"]]);export{h as default};
