/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as l}from"./index.vue_vue_type_script_setup_true_lang-kw-wsGJ1.js";import{x as u,u as m,A as p,B as d,e as f,_ as x}from"./index-CJ7U9r9H.js";import{d as b,o as h,b as k,W as e,T as v,u as y,bj as B}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const w={class:"no-layout-container"},g=b({name:"NoLayout",__name:"index",setup(A){const t=u(),a=m(),{delVisitedRoute:o}=t,{exit:s,isFullscreen:n}=p(),c=async()=>{await s(),await o(d(a,!0)),await history.back()};return(C,E)=>{const r=f,_=B,i=l;return h(),k("div",w,[e(_,{content:"全屏",title:y(n)?"退出全屏并返回上一页":"返回上一页",onBack:c},{extra:v(()=>[e(r)]),_:1},8,["title"]),e(i,{title:"刷新浏览器自动退出全屏",type:"success"})])}}}),T=x(g,[["__scopeId","data-v-e7f2f52e"]]);export{T as default};
