/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as n,o as r,S as c,bv as o}from"./vsv-element-plus-DDEqdpLt.js";const i=n({__name:"TreeBasic",setup(b){const e=[{label:"一级 1",children:[{label:"二级 1-1",children:[{label:"三级 1-1-1"}]}]},{label:"一级 2",children:[{label:"二级 2-1",children:[{label:"三级 2-1-1"}]},{label:"二级 2-2",children:[{label:"三级 2-2-1"}]}]},{label:"一级 3",children:[{label:"二级 3-1",children:[{label:"三级 3-1-1"}]},{label:"二级 3-2",children:[{label:"三级 3-2-1"}]}]}],l={children:"children",label:"label"};return(t,s)=>{const a=o;return r(),c(a,{data:e,props:l})}}});export{i as _};
