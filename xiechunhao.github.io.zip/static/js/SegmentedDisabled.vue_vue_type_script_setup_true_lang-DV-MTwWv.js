/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as p,r,o as i,S as c,T as t,W as l,u as m,h as _,cd as v,b7 as f,b8 as V}from"./vsv-element-plus-DDEqdpLt.js";const x=p({__name:"SegmentedDisabled",setup(g){const a=r("Mon"),o=r("Mon"),u=[{label:"周一",value:"Mon",disabled:!0},{label:"周二",value:"Tue"},{label:"周三",value:"Wed",disabled:!0},{label:"周四",value:"Thu"},{label:"周五",value:"Fri",disabled:!0},{label:"周六",value:"Sat"},{label:"周日",value:"Sun"}];return(S,e)=>{const s=v,d=f,b=V;return i(),c(b,{gutter:20},{default:t(()=>[l(d,{span:24},{default:t(()=>[l(s,{modelValue:m(a),"onUpdate:modelValue":e[0]||(e[0]=n=>_(a)?a.value=n:null),disabled:"",options:u,style:{"margin-bottom":"var(--el-margin)"}},null,8,["modelValue"])]),_:1}),l(d,{span:24},{default:t(()=>[l(s,{modelValue:m(o),"onUpdate:modelValue":e[1]||(e[1]=n=>_(o)?o.value=n:null),options:u},null,8,["modelValue"])]),_:1})]),_:1})}}});export{x as _};
