/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as s}from"./index-CJ7U9r9H.js";import{o as a,S as n,T as t,b as c,a3 as _,aj as l,W as p,e as u,a1 as i,bg as m,bh as d}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const f={};function h(g,x){const o=m,r=d;return a(),n(r,{height:"180px",interval:4e3,type:"card"},{default:t(()=>[(a(),c(_,null,l(3,e=>p(o,{key:e},{default:t(()=>[u("h3",null,i(e),1)]),_:2},1024)),64))]),_:1})}const C=s(f,[["render",h],["__scopeId","data-v-f1af3d84"]]);export{C as default};
