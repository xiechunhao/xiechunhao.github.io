/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as t,o,S as n,T as l,e as r,V as c,b7 as p}from"./vsv-element-plus-DDEqdpLt.js";const d={class:"right-panel"},i=t({__name:"VabQueryFormRightPanel",props:{span:{type:Number,default:10}},setup(e){return(a,m)=>{const s=p;return o(),n(s,{lg:e.span,md:24,sm:24,xl:e.span,xs:24},{default:l(()=>[r("div",d,[c(a.$slots,"default")])]),_:3},8,["lg","xl"])}}});export{i as _};
