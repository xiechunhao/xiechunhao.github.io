/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as c}from"./index-CJ7U9r9H.js";import{o as r,b as s,W as t,bD as o}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const n={},p={class:"demo-progress"};function a(_,i){const e=o;return r(),s("div",p,[t(e,{percentage:0,type:"circle"}),t(e,{percentage:25,type:"circle"}),t(e,{percentage:100,status:"success",type:"circle"}),t(e,{percentage:70,status:"warning",type:"circle"}),t(e,{percentage:50,status:"exception",type:"circle"})])}const u=c(n,[["render",a],["__scopeId","data-v-95d900d8"]]);export{u as default};
