/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as u,r as d,o as _,S as i,T as t,W as l,a8 as p,e as f,a9 as c,c1 as m}from"./vsv-element-plus-DDEqdpLt.js";const g=u({__name:"UploadManual",setup(k){const a=d(),n=()=>{var o;(o=a.value)==null||o.submit()};return(o,e)=>{const s=c,r=m;return _(),i(r,{ref_key:"uploadRef",ref:a,action:"/uploadFile","auto-upload":!1},{trigger:t(()=>[l(s,{type:"primary"},{default:t(()=>e[0]||(e[0]=[p("选择文件")])),_:1})]),tip:t(()=>e[2]||(e[2]=[f("div",{class:"el-upload__tip"},"jpg/png 文件需小于500kb",-1)])),default:t(()=>[l(s,{type:"success",onClick:n},{default:t(()=>e[1]||(e[1]=[p("上传到服务器")])),_:1})]),_:1},512)}}});export{g as _};
