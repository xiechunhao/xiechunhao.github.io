/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{ay as e,_ as t}from"./index-CJ7U9r9H.js";import{d as r,o as n,b as a,W as _}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const c={class:"errorLog-container auto-height-container"},s=r({name:"ErrorLog",__name:"index",setup(i){return(m,p)=>{const o=e;return n(),a("div",c,[_(o)])}}}),x=t(s,[["__scopeId","data-v-f8f5fd7d"]]);export{x as default};
