/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as e,a7 as t,o,b as n}from"./vsv-element-plus-DDEqdpLt.js";const r={class:"redirect-container"},_=e({name:"Redirect",__name:"Redirect",setup(a){return t(()=>{setTimeout(()=>{history.back()},500)}),(c,s)=>(o(),n("div",r))}});export{_ as default};
