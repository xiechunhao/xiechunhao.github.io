/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as r}from"./InfiniteScrollDisableLoading.vue_vue_type_style_index_0_lang-BtcqA7E1.js";import{_ as s}from"./index-CNDUKRL3.js";import{_ as c}from"./InfiniteScrollBasic.vue_vue_type_style_index_0_lang-CpEAVjWK.js";import{d as l,o as m,b as p,W as o,T as t,a8 as i}from"./vsv-element-plus-DDEqdpLt.js";import"./index-CJ7U9r9H.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const d={class:"infinite-scroll-container no-background-container"},N=l({name:"InfiniteScroll",__name:"index",setup(f){return(u,n)=>{const _=c,e=s,a=r;return m(),p("div",d,[o(e,null,{header:t(()=>n[0]||(n[0]=[i("基础用法")])),default:t(()=>[o(_)]),_:1}),o(e,null,{header:t(()=>n[1]||(n[1]=[i("禁用加载")])),default:t(()=>[o(a)]),_:1})])}}});export{N as default};
