/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{k as t}from"./index-CJ7U9r9H.js";const r=()=>t({url:"/area/getList",method:"get"});export{r as g};
