/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as c}from"./ErrorContainer.vue_vue_type_style_index_0_lang-CFvSY7wY.js";import{d as _,r as o,o as i,S as p,u as n}from"./vsv-element-plus-DDEqdpLt.js";const h=_({__name:"500",setup(f){const e=o("抱歉！"),t=o("服务器发生错误。"),s=o("请稍后重试，或点击下面的按钮返回首页。"),r=o("返回首页");return(m,l)=>{const a=c;return i(),p(a,{btn:n(r),headline:n(t),icon:"500",info:n(s),oops:n(e)},null,8,["btn","headline","info","oops"])}}});export{h as default};
