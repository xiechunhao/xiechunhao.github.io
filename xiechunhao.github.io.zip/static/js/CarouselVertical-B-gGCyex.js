/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as i}from"./index-CJ7U9r9H.js";import{o as r,b as l,W as a,T as t,a3 as o,aj as c,e as _,a1 as u,bg as p,bh as d}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const f={};function m(h,g){const n=p,s=d;return r(),l(o,null,[a(s,{autoplay:!1,direction:"vertical",height:"180px"},{default:t(()=>[(r(),l(o,null,c(3,e=>a(n,{key:e},{default:t(()=>[_("h3",null,u(e),1)]),_:2},1024)),64))]),_:1}),a(s,{autoplay:!1,direction:"vertical",height:"180px",style:{"margin-top":"var(--el-margin)"},type:"card"},{default:t(()=>[(r(),l(o,null,c(3,e=>a(n,{key:e},{default:t(()=>[_("h3",null,u(e),1)]),_:2},1024)),64))]),_:1})],64)}const b=i(f,[["render",m],["__scopeId","data-v-51ffdf24"]]);export{b as default};
