/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as p,r as m,o as f,b as _,W as t,T as s,a8 as l,e as c,n as C,u as r,cl as w,h as V,a3 as k,a9 as x,aw as b}from"./vsv-element-plus-DDEqdpLt.js";const v=["id"],E=p({__name:"DrawerCustomizationHeader",setup(y){const a=m(!1);return(B,e)=>{const n=x,d=b;return f(),_(k,null,[t(n,{type:"primary",onClick:e[0]||(e[0]=o=>a.value=!0)},{default:s(()=>e[2]||(e[2]=[l("打开")])),_:1}),t(d,{modelValue:r(a),"onUpdate:modelValue":e[1]||(e[1]=o=>V(a)?a.value=o:null),"append-to-body":"","show-close":!1,size:"288px"},{header:s(({close:o,titleId:i,titleClass:u})=>[c("span",{id:i,class:C(u)},"自定义头部",10,v),t(n,{icon:r(w),type:"danger",onClick:o},{default:s(()=>e[3]||(e[3]=[l("关闭")])),_:2},1032,["icon","onClick"])]),default:s(()=>[e[4]||(e[4]=l(" 这是抽屉内容 "))]),_:1},8,["modelValue"])],64)}}});export{E as _};
