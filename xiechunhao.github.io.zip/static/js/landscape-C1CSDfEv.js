/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
const a=""+new URL("../jpg/landscape-BDpPTB9a.jpg",import.meta.url).href;export{a as l};
