/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as i,by as s,o as c,S as p,bk as f,T as o,V as l,a8 as a,a1 as n,U as d,u as m}from"./vsv-element-plus-DDEqdpLt.js";const b=i({name:"VabAlert",__name:"index",props:{...s.props,closable:{type:Boolean,default:!1}},setup(r){const e=r;return(t,u)=>(c(),p(m(s),d({center:e.center,closable:e.closable,"close-text":e.closeText,description:e.description,effect:e.effect,"show-icon":e.showIcon,title:e.title,type:e.type},t.$attrs),f({_:2},[e.title||t.$slots.title?{name:"title",fn:o(()=>[l(t.$slots,"title",{},()=>[a(n(e.title),1)])]),key:"0"}:void 0,t.$slots.default||e.description?{name:"default",fn:o(()=>[l(t.$slots,"default",{},()=>[a(n(e.description),1)])]),key:"1"}:void 0]),1040,["center","closable","close-text","description","effect","show-icon","title","type"]))}});export{b as _};
