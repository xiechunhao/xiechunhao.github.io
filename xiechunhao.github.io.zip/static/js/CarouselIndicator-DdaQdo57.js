/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as r}from"./index-CJ7U9r9H.js";import{o as t,S as n,T as o,b as c,a3 as _,aj as l,W as i,e as p,a1 as u,bg as d,bh as m}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const f={};function h(g,x){const a=d,s=m;return t(),n(s,{height:"180px","indicator-position":"outside"},{default:o(()=>[(t(),c(_,null,l(3,e=>i(a,{key:e},{default:o(()=>[p("h3",null,u(e),1)]),_:2},1024)),64))]),_:1})}const E=r(f,[["render",h],["__scopeId","data-v-97959ccd"]]);export{E as default};
