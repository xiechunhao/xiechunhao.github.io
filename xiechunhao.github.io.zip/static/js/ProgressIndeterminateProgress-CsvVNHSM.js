/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as s,o,b as a,W as t,bD as c}from"./vsv-element-plus-DDEqdpLt.js";import{_ as i}from"./index-CJ7U9r9H.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const p={class:"demo-progress"},_=s({__name:"ProgressIndeterminateProgress",setup(m){const n=r=>r===100?"Full":`${r}%`;return(r,u)=>{const e=c;return o(),a("div",p,[t(e,{indeterminate:!0,percentage:50}),t(e,{format:n,indeterminate:!0,percentage:100}),t(e,{duration:5,indeterminate:!0,percentage:100,status:"success"}),t(e,{duration:1,indeterminate:!0,percentage:100,status:"warning"}),t(e,{indeterminate:!0,percentage:50,status:"exception"})])}}}),x=i(_,[["__scopeId","data-v-1543ac0c"]]);export{x as default};
