/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as r,o as s,S as c,bv as l}from"./vsv-element-plus-DDEqdpLt.js";const f=r({__name:"TreeCustomLeafNodeInLazyMode",setup(m){const n={label:"name",children:"zones",isLeaf:"leaf"},t=(a,e)=>{if(a.level===0)return e([{name:"region"}]);if(a.level>1)return e([]);setTimeout(()=>{e([{name:"leaf",leaf:!0},{name:"zone"}])},500)};return(a,e)=>{const o=l;return s(),c(o,{lazy:"",load:t,props:n,"show-checkbox":""})}}});export{f as _};
