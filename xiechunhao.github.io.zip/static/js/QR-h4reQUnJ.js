/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
const e=""+new URL("../png/QR-CvToeGk7.png",import.meta.url).href;export{e as Q};
