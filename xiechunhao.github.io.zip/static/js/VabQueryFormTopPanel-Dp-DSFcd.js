/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as s}from"./index-CJ7U9r9H.js";import{o as t,S as n,T as _,e as a,V as c,b7 as r}from"./vsv-element-plus-DDEqdpLt.js";const l={},p={class:"top-panel"};function d(o,f){const e=r;return t(),n(e,{span:24},{default:_(()=>[a("div",p,[c(o.$slots,"default")])]),_:3})}const u=s(l,[["render",d]]);export{u as _};
