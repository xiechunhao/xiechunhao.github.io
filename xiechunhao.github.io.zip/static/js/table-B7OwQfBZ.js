/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{k as e}from"./index-CJ7U9r9H.js";function r(t){return e({url:"/table/getList",method:"get",params:t})}const s=t=>e({url:"/table/doEdit",method:"post",data:t}),d=t=>e({url:"/table/doDelete",method:"post",data:t});export{s as a,d,r as g};
