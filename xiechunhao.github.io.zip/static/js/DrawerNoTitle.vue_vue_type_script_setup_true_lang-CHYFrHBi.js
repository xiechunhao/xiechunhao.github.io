/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as s,r as u,o as d,b as p,W as o,T as n,a8 as m,e as f,u as i,h as _,a3 as w,a9 as V,aw as x}from"./vsv-element-plus-DDEqdpLt.js";const k=s({__name:"DrawerNoTitle",setup(B){const a=u(!1);return(N,e)=>{const r=V,l=x;return d(),p(w,null,[o(r,{type:"primary",onClick:e[0]||(e[0]=t=>a.value=!0)},{default:n(()=>e[2]||(e[2]=[m("打开")])),_:1}),o(l,{modelValue:i(a),"onUpdate:modelValue":e[1]||(e[1]=t=>_(a)?a.value=t:null),"append-to-body":"",size:"288px","with-header":!1},{default:n(()=>e[3]||(e[3]=[f("span",null,"我是内容",-1)])),_:1},8,["modelValue"])],64)}}});export{k as _};
