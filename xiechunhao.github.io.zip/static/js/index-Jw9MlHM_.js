/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as a}from"./index.vue_vue_type_script_setup_true_lang-kw-wsGJ1.js";import{c as r,s as c}from"./index-CJ7U9r9H.js";import{d as m,o as e,b as i,u as _,S as o}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const l={class:"delete-column-container"},h=m({name:"DeleteColumn",__name:"index",setup(p){const n=r(),{theme:s}=c(n);return(u,f)=>{const t=a;return e(),i("div",l,[_(s).layout=="column"?(e(),o(t,{key:0,title:"单栏页面演示"})):(e(),o(t,{key:1,title:"当前布局不支持单栏页面演示",type:"warning"}))])}}});export{h as default};
