/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as o,r,Z as l,o as e,b as t,a3 as c,aj as _,u,ck as f,a1 as m}from"./vsv-element-plus-DDEqdpLt.js";const p={class:"infinite-list",style:{overflow:"auto"}},y=o({__name:"InfiniteScrollBasic",setup(d){const s=r(0),i=()=>{s.value+=2};return(k,v)=>{const a=f;return l((e(),t("ul",p,[(e(!0),t(c,null,_(u(s),n=>(e(),t("li",{key:n,class:"infinite-list-item"},m(n),1))),128))])),[[a,i]])}}});export{y as _};
