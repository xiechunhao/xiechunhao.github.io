/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as s}from"./index-CJ7U9r9H.js";import{o as r,b as o,W as t,bD as n}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const c={},a={class:"demo-progress"};function i(d,p){const e=n;return r(),o("div",a,[t(e,{percentage:70,"stroke-width":26,"text-inside":!0}),t(e,{percentage:100,status:"success","stroke-width":24,"text-inside":!0}),t(e,{percentage:80,status:"warning","stroke-width":22,"text-inside":!0}),t(e,{percentage:50,status:"exception","stroke-width":20,"text-inside":!0})])}const f=s(c,[["render",i],["__scopeId","data-v-6df422a8"]]);export{f as default};
