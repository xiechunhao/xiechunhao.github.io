/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as t,r as a,o as m,S as r,u,h as c,cd as d}from"./vsv-element-plus-DDEqdpLt.js";const i=t({__name:"SegmentedBlock",setup(p){const e=a("周一"),n=["周一","周二","周三","周四","周五","周六","周日"];return(_,o)=>{const l=d;return m(),r(l,{modelValue:u(e),"onUpdate:modelValue":o[0]||(o[0]=s=>c(e)?e.value=s:null),block:"",options:n},null,8,["modelValue"])}}});export{i as _};
