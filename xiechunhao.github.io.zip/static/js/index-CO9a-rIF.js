/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import r from"./StatisticCard-uMHE4GMR.js";import m from"./StatisticCountdown-BUa-5yKk.js";import{_ as p}from"./index-CNDUKRL3.js";import c from"./StatisticBasic-CPZ3Fwm7.js";import{d as u,o as d,b as l,W as n,T as o,a8 as _}from"./vsv-element-plus-DDEqdpLt.js";import"./index-CJ7U9r9H.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const f={class:"statistic-container no-background-container"},V=u({name:"Statistic",__name:"index",setup(g){return(x,t)=>{const s=c,e=p,i=m,a=r;return d(),l("div",f,[n(e,null,{header:o(()=>t[0]||(t[0]=[_("基础用法")])),default:o(()=>[n(s)]),_:1}),n(e,null,{header:o(()=>t[1]||(t[1]=[_("倒计时")])),default:o(()=>[n(i)]),_:1}),n(e,null,{header:o(()=>t[2]||(t[2]=[_("卡片")])),default:o(()=>[n(a)]),_:1})])}}});export{V as default};
