/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{k as e}from"./index-CJ7U9r9H.js";function n(t){return e({url:"/goodsManagement/getList",method:"get",params:t})}const r=t=>e({url:"/table/doDelete",method:"post",data:t});export{r as d,n as g};
