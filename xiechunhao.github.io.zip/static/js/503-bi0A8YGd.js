/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as c}from"./ErrorContainer.vue_vue_type_style_index_0_lang-CFvSY7wY.js";import{d as _,r as o,o as i,S as p,u as n}from"./vsv-element-plus-DDEqdpLt.js";const h=_({__name:"503",setup(f){const e=o("抱歉！"),t=o("服务不可用。"),s=o("服务器当前无法处理请求，可能是由于过载或正在进行维护。"),r=o("返回首页");return(m,l)=>{const a=c;return i(),p(a,{btn:n(r),headline:n(t),icon:"503",info:n(s),oops:n(e)},null,8,["btn","headline","info","oops"])}}});export{h as default};
