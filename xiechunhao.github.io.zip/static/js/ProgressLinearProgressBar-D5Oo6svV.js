/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as r,o as n,b as a,W as s,bD as c}from"./vsv-element-plus-DDEqdpLt.js";import{_ as p}from"./index-CJ7U9r9H.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const _={class:"demo-progress"},m=r({__name:"ProgressLinearProgressBar",setup(i){const o=t=>t===100?"Full":`${t}%`;return(t,g)=>{const e=c;return n(),a("div",_,[s(e,{percentage:50}),s(e,{format:o,percentage:100}),s(e,{percentage:100,status:"success"}),s(e,{percentage:100,status:"warning"}),s(e,{percentage:50,status:"exception"})])}}}),x=p(m,[["__scopeId","data-v-fb6f12d6"]]);export{x as default};
