/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as r,e as i}from"./index-CJ7U9r9H.js";import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BOVLG7qV.js";import{$ as p,o as d,S as f,T as e,W as o,e as n,b7 as u,b8 as b}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const v={},h={class:"data-screen-header"},x={class:"data-go-home"};function k(V,t){const s=p("vab-icon"),a=m,_=i,c=u,l=b;return d(),f(l,null,{default:e(()=>[o(c,{span:24},{default:e(()=>[n("div",h,[o(a,{target:"_blank",to:"/index"},{default:e(()=>[n("div",x,[o(s,{icon:"home-2-line"})])]),_:1}),t[0]||(t[0]=n("span",null,"Vue Shop Vite 工作台",-1)),o(_,{class:"data-fullscreen"})])]),_:1})]),_:1})}const E=r(v,[["render",k],["__scopeId","data-v-0ecb37c3"]]);export{E as default};
