/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as i}from"./index.vue_vue_type_script_setup_true_lang-kw-wsGJ1.js";import{V as c}from"./vue-json-viewer-CYH9DI1m.js";import{u as m,x as p}from"./index-CJ7U9r9H.js";import{d as l,p as _,w as d,Q as y,o as f,b as h,W as r,u as a}from"./vsv-element-plus-DDEqdpLt.js";import"./vue.runtime.esm-bundler-CFlbZaFX.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const b={class:"test2-container"},T=l({name:"Query",__name:"query",setup(q){const e=m(),n=p(),{changeTabsMeta:s}=n,t=_({name:"",path:"",query:{}}),o=()=>{t.name=e.name,t.path=e.path,t.query=e.query,s({title:"Query",meta:{title:`Query id=${e.query.id} `}})};return d(t,()=>{o()},{immediate:!0}),y(()=>{o()}),(v,Q)=>{const u=i;return f(),h("div",b,[r(u,{title:"Query id="+a(e).query.id},null,8,["title"]),r(a(c),{copyable:"","expand-depth":5,value:a(t)},null,8,["value"])])}}});export{T as default};
