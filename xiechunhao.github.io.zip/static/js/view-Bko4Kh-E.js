/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{x as c,u as n,_ as m}from"./index-CJ7U9r9H.js";import{d as i,r as u,w as _,o as f,b as p,e as l,u as d,x as h}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const x={class:"iframe-container"},v=["src"],b=i({name:"Iframe",__name:"view",setup(w){const s=c(),{changeTabsMeta:o}=s,e=n(),t=u(""),r=()=>{t.value=`https://${e.query.url}`;const a={...e.meta,...e.query};h(()=>{o({title:"Iframe",meta:a})})};return _(e,()=>{r()},{immediate:!0}),(a,I)=>(f(),p("div",x,[l("iframe",{src:d(t)},null,8,v)]))}}),y=m(b,[["__scopeId","data-v-39f74e7c"]]);export{y as default};
