/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as t,o as a,S as r,T as s,V as _,b8 as n}from"./vsv-element-plus-DDEqdpLt.js";import{_ as c}from"./index-CJ7U9r9H.js";const p=t({name:"VabQueryForm",__name:"index",setup(m){return(o,u)=>{const e=n;return a(),r(e,{class:"vab-query-form",gutter:0},{default:s(()=>[_(o.$slots,"default",{},void 0,!0)]),_:3})}}}),f=c(p,[["__scopeId","data-v-a03dcaab"]]);export{f as _};
