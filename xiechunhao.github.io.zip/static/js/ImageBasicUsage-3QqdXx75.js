/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as _,r as o,o as s,b as a,a3 as l,aj as m,u as t,e as i,a1 as p,W as d,bd as u}from"./vsv-element-plus-DDEqdpLt.js";import{_ as f}from"./index-CJ7U9r9H.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const g={class:"demo-image"},h={class:"demonstration"},k=_({__name:"ImageBasicUsage",setup(v){const n=o(["fill","contain","cover","none","scale-down"]),c=o("https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg");return(B,b)=>{const r=u;return s(),a("div",g,[(s(!0),a(l,null,m(t(n),e=>(s(),a("div",{key:e,class:"block"},[i("span",h,p(e),1),d(r,{fit:e,src:t(c)},null,8,["fit","src"])]))),128))])}}}),E=f(k,[["__scopeId","data-v-941ede7c"]]);export{E as default};
