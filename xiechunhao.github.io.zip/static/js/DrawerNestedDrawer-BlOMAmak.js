/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as m}from"./DrawerNestedDrawer.vue_vue_type_script_setup_true_lang-CtjxuS11.js";import"./vsv-element-plus-DDEqdpLt.js";export{m as default};
