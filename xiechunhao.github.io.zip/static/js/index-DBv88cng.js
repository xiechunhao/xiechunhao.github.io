/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{_ as o}from"./index.vue_vue_type_style_index_0_lang-CHnxE-ex.js";import"./index.min-CJtEb593.js";import"./vsv-element-plus-DDEqdpLt.js";export{o as default};
