/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{N as e}from"./index-CJ7U9r9H.js";import{d as s,a as p,o as i,S as l,T as c,V as u,bM as m,bN as d,az as f,u as _}from"./vsv-element-plus-DDEqdpLt.js";const x=s({name:"VabLink",__name:"index",props:{to:{type:String,required:!0},target:{type:String,default:""}},setup(o){const t=o,r=p(()=>e(t.to)?"a":"router-link"),a=()=>e(t.to)?{href:t.to,target:"_blank",rel:"noopener"}:{to:t.to,target:t.target};return(n,g)=>(i(),l(f(_(r)),m(d(a())),{default:c(()=>[u(n.$slots,"default")]),_:3},16))}});export{x as _};
