/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{k as t}from"./index-CJ7U9r9H.js";const o=()=>t({url:"https://api.vuejs-core.cn/getShopDescription",method:"get"});export{o as g};
