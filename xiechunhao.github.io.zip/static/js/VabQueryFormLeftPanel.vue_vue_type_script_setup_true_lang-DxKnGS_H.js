/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{d as t,o,S as l,T as n,e as r,V as c,b7 as p}from"./vsv-element-plus-DDEqdpLt.js";const d={class:"left-panel"},f=t({__name:"VabQueryFormLeftPanel",props:{span:{type:Number,default:14}},setup(e){return(a,m)=>{const s=p;return o(),l(s,{lg:e.span,md:24,sm:24,xl:e.span,xs:24},{default:n(()=>[r("div",d,[c(a.$slots,"default")])]),_:3},8,["lg","xl"])}}});export{f as _};
