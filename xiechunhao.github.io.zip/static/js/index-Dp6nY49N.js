/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{f as s}from"./index-CJ7U9r9H.js";import{d as _,aL as r,o as t,b as m,Z as n,S as c,T as a,a8 as i,a9 as b}from"./vsv-element-plus-DDEqdpLt.js";import"./vsv-icon-DFkIF_Wl.js";import"./vsv-nprogress-CAgsOcyS.js";const f={class:"throttle-debounce-container"},C=_({name:"ThrottleDebounce",__name:"index",setup(h){const l=()=>{s("节流函数，2秒后允许再次触发","success","hey")},d=()=>{s("防抖函数，每隔1秒允许触发一次","success","hey")};return(v,e)=>{const o=b,p=r("throttle"),u=r("debounce");return t(),m("div",f,[n((t(),c(o,{type:"primary"},{default:a(()=>e[0]||(e[0]=[i("节流函数")])),_:1})),[[p,l]]),n((t(),c(o,{type:"primary"},{default:a(()=>e[1]||(e[1]=[i("防抖函数")])),_:1})),[[u,d]])])}}});export{C as default};
