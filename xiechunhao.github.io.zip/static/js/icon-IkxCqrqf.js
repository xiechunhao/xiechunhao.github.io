/*!  build: Vue Shop Vite 
     copyright: https://vuejs-core.cn/shop-vite   
     time: 2024-11-12 17:58:14 
 */
import{k as e}from"./index-CJ7U9r9H.js";const n=t=>e({url:"/icon/getList",method:"get",params:t});export{n as g};
